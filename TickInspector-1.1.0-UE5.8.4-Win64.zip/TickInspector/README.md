# Tick Inspector

Standalone C++ Editor-only plugin for Unreal Engine 5.8.4 on Windows x64. No project content, Python, runtime module, or other project plugin is required.

## Open the inspector

Place this folder at `<Project>/Plugins/TickInspector`, restart Unreal Editor, and click **Tick Inspector** on the Level Editor toolbar. The same inspector is available at **Tools > Tick Inspector**. Repeated activation focuses the existing dockable tab. Check **Edit > Plugins > Tick Inspector** if it has been explicitly disabled in your project.

The binary distribution targets the installed UE 5.8.4 build. Other engine builds require recompilation from the included source. Windows x64 is the supported and tested platform; other platforms are not advertised by the descriptor.

## Inspect

Choose **Editor** or an individual **PIE** world. Search actor/component names, class, group, level or object path. Choose a filter and click a column header to sort. Ctrl/Shift selects multiple rows. Click selects the owning editor actor; **Focus on click** also moves the active editor camera. Double-click focuses the owner. PIE navigation uses an editor counterpart where one exists; runtime-only objects remain inspectable without a guessed editor match.

Discovery covers `PrimaryActorTick` and `PrimaryComponentTick` on loaded actors and their components. It includes incapable and disabled ticks so they can be distinguished. It does not enumerate arbitrary secondary native tick functions, timers, subsystem tickers or asynchronous tasks. Discovery snapshots do not measure cost; use the separate PIE performance capture below.

## Measure PIE tick performance

Set **PIE performance capture (seconds)** (default **10**, range 0.1–600), then click **Run PIE & measure**. This launches one local standalone-mode PIE world using temporary play settings. The wall-clock deadline starts at `PostPIEStarted`, excluding editor launch/compilation time. The core ticker enforces the deadline even if the inspector is hidden. **Stop measurement**, the editor's normal Stop button, or the deadline ends PIE and analyzes the recording. A results window opens automatically; **Show last results** reopens it. Closing the inspector cancels its owned capture.

Results rank actor instances by recorded CPU time, aggregating each actor's primary tick and its owned primary component ticks. The bar chart shows each actor's share of the measured tick CPU, with total milliseconds, milliseconds per captured PIE frame, maximum individual tick duration, and execution count. Unmeasured actors are marked **No attributable tick samples**, not assigned an inferred zero. Capture-local UObject stat identifiers preserve ownership after PIE objects are destroyed and distinguish same-named components and numbered actor instances; original stat identifiers are restored before PIE cleanup. Spawned and streamed-in actors are discovered at each world pre-actor tick; objects created and destroyed between those scans may remain unattributed. Unloaded actors are not force-loaded.

Capture uses Unreal CPU Trace and TraceServices. It temporarily enables UObject/task timing stats and named events, and disables `tick.AllowBatchedTicks` for reliable per-instance attribution; previous settings are restored on stop, startup failure, or cleanup. Another active trace or play session prevents starting a capture. Inspector scanning and bounds highlighting pause while measuring. Traces are retained in `Saved/TickInspector/Captures/*.utrace` for inspection in Unreal Insights.

These are inclusive synchronous CPU scope durations, not total actor cost, GPU cost, or predicted FPS savings. Nested scopes are not charged twice. Worker-thread durations can overlap; summed CPU time is not frame wall time. Detached async work, secondary custom tick functions and work outside primary ticks are not attributed. PIE, stats collection, ownership discovery, and disabling batching affect the workload. Confirm optimization results in a packaged Development build with Unreal Insights.

Scans are incremental on the game thread with an approximately 2 ms budget per frame and repeat every two seconds while the tab is visible. One actor's component enumeration and snapshot publishing/filtering can exceed that budget on unusually large objects or result sets. **Cancel scan** cancels the current scan and retains the last completed snapshot; the normal automatic refresh still resumes. Closing the tab stops its work. A snapshot is not a synchronized recording of an entire running frame.

## Change ticks

The operation scope is determined by the explicitly selected world and displayed above the controls:

| World | Enable/disable | Interval/group | Lifetime |
| --- | --- | --- | --- |
| Editor | Changes the serialized startup-enabled flag | Changes serialized configuration | Save modified actors/levels; Undo/Redo supported |
| PIE | Changes current Tick enabled state | Changes that session's configuration/cooldown | Temporary; discarded when PIE ends |

Stop PIE before making persistent edits. The tool never copies PIE values back to editor objects. It never forces `bCanEverTick`, registers an otherwise unregistered tick, edits archetypes/CDOs, changes prerequisites, or checks out/saves assets automatically. Valid intervals are finite and nonnegative; zero means every eligible frame. Start-group choices exclude internal scheduler groups. Prerequisites can delay actual execution beyond the configured group.

Each persistent batch uses one transaction. Already-matching values do not produce changes. Missing, stale, world-mismatched, transient, nontransactional or locked-level targets are skipped, with counts and reasons. Construction-script components are intentionally read-only for persistent operations: configure their owning Blueprint defaults instead, because reconstruction can discard instance overrides. Native and instance-created components are eligible, but project-specific construction code can still overwrite configuration.

Use the editor's normal Save and source-control workflow. World Partition external actor packages are marked dirty as appropriate. Review the changed values before saving. Undo restores serialized configuration, not internal tick scheduler history.

## Highlighting and CSV

**Highlight bounds** draws cyan projected bounds for at most 128 distinct selected owners in the matching viewport world. Bounds are refreshed at 10 Hz. It changes no materials, custom depth, actor transforms or saved properties. The **On Screen Debug** viewport show flag must be enabled. Bounds are an overlay, not an occlusion-aware outline.

CSV exports either the selected rows or the currently filtered snapshot. It includes world identity, snapshot UTC time, export scope, configuration and sampled runtime state. Quotes, commas, Unicode and newlines are preserved. Text beginning with spreadsheet formula characters is prefixed with an apostrophe for safe spreadsheet viewing. Exports do not load additional actors.

## World Partition and diagnostics

Only loaded actors/components are inspected. No cells are force-loaded or pinned. Unloaded actors' component inventories and Tick state are unknown and are not represented as disabled ticks. Refresh accounts for level streaming and UObject replacement/cleanup. Out-of-process games and remote clients are not inspected by this Editor-only module.

Diagnostics in the discovery table are configuration observations, not profiling results. Unregistered state can be normal in an editor world. Enabled does not imply execution this frame; intervals, world mode, pause and prerequisites affect scheduling. Existing negative intervals follow the engine's `<= 0` every-frame semantics; the inspector's editing controls accept nonnegative values. Use the PIE capture for measured primary tick CPU scopes and **Unreal Insights** for broader profiling.

See [Architecture](Documentation/Architecture.md), [Validation](Documentation/Validation.md) and [Packaging](Documentation/Packaging.md).
