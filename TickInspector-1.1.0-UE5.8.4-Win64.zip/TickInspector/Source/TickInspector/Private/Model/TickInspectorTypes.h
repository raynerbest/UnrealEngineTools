#pragma once
#include "CoreMinimal.h"
#include "Engine/EngineBaseTypes.h"

class AActor;
class UActorComponent;
class UWorld;

namespace TickInspector
{
struct FWorldChoice
{
    TWeakObjectPtr<UWorld> World;
    FString Label;
};

// Value snapshot only. FTickFunction is deliberately never copied or retained.
struct FRow
{
    TWeakObjectPtr<UObject> Object;
    TWeakObjectPtr<AActor> Owner;
    FString Key, ActorName, Name, ClassName, Level, SearchText;
    bool bComponent = false, bCanTick = false, bStartEnabled = false;
    bool bEnabled = false, bRegistered = false, bComponentRegistered = false;
    bool bAnyThread = false, bPaused = false, bDedicatedServer = false;
    float Interval = 0;
    ETickingGroup Group = TG_PrePhysics, EndGroup = TG_PrePhysics;
    int32 Prerequisites = 0;
    FDateTime Captured;
};
using FRowPtr = TSharedPtr<FRow>;

FTickFunction* ResolveTick(UObject* Object);
FRowPtr Capture(UObject* Object);
FString GroupName(ETickingGroup Group);
}
