#include "TickViewportVisualization.h"
#include "Debug/DebugDrawService.h"
#include "Engine/Canvas.h"
#include "Engine/World.h"
#include "GameFramework/Actor.h"
#include "SceneView.h"
#include "SceneInterface.h"
#include "UObject/ObjectKey.h"

namespace TickInspector
{
FViewportVisualization::FViewportVisualization()
{
    DrawHandle = UDebugDrawService::Register(TEXT("OnScreenDebug"), FDebugDrawDelegate::CreateRaw(this, &FViewportVisualization::Draw));
}
FViewportVisualization::~FViewportVisualization() { UDebugDrawService::Unregister(DrawHandle); }

void FViewportVisualization::Update(UWorld* InWorld, const TArray<FRowPtr>& Selection, bool bEnabled)
{
    check(IsInGameThread());
    World = InWorld;
    Boxes.Reset();
    if (!bEnabled || !IsValid(InWorld)) { return; }
    TSet<FObjectKey> Seen;
    for (const auto& Row : Selection)
    {
        AActor* Actor = Row ? Row->Owner.Get() : nullptr;
        if (!IsValid(Actor) || Actor->IsActorBeingDestroyed() || Actor->GetWorld() != InWorld || Seen.Contains(FObjectKey(Actor))) { continue; }
        Seen.Add(FObjectKey(Actor));
        FVector Origin, Extent;
        Actor->GetActorBounds(false, Origin, Extent);
        if (Origin.ContainsNaN() || Extent.ContainsNaN()) { continue; }
        if (Extent.IsNearlyZero()) { Origin = Actor->GetActorLocation(); Extent = FVector(15); }
        Boxes.Add(FBox::BuildAABB(Origin, Extent));
        if (Boxes.Num() >= MaxActors) { break; }
    }
}

void FViewportVisualization::Draw(UCanvas* Canvas, APlayerController*)
{
    if (!IsInGameThread() || Boxes.IsEmpty() || !World.IsValid() || !Canvas || !Canvas->SceneView || !Canvas->SceneView->Family ||
        !Canvas->SceneView->Family->Scene || Canvas->SceneView->Family->Scene->GetWorld() != World.Get()) { return; }
    static const int32 Edges[12][2] = {{0,1},{0,2},{1,3},{2,3},{4,5},{4,6},{5,7},{6,7},{0,4},{1,5},{2,6},{3,7}};
    for (const FBox& Box : Boxes)
    {
        FVector2D Screen[8];
        bool Visible[8];
        for (int32 Index = 0; Index < 8; ++Index)
        {
            const FVector Position((Index & 1) ? Box.Max.X : Box.Min.X, (Index & 2) ? Box.Max.Y : Box.Min.Y, (Index & 4) ? Box.Max.Z : Box.Min.Z);
            Visible[Index] = Canvas->SceneView->WorldToPixel(Position, Screen[Index]);
            Screen[Index] -= FVector2D(Canvas->SceneView->UnscaledViewRect.Min);
        }
        for (const auto& Edge : Edges)
        {
            if (Visible[Edge[0]] && Visible[Edge[1]]) { Canvas->K2_DrawLine(Screen[Edge[0]], Screen[Edge[1]], 2.0f, FLinearColor(0.0f, 0.8f, 1.0f)); }
        }
    }
}
}
