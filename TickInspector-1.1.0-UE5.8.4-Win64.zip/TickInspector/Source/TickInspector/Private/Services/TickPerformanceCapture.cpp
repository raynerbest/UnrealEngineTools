#include "TickPerformanceCapture.h"
#include "Editor.h"
#include "Engine/World.h"
#include "EngineUtils.h"
#include "Components/ActorComponent.h"
#include "PlayInEditorDataTypes.h"
#include "Settings/LevelEditorPlaySettings.h"
#include "HAL/FileManager.h"
#include "Misc/Paths.h"
#include "Modules/ModuleManager.h"
#include "ProfilingDebugging/TraceAuxiliary.h"
#include "ProfilingDebugging/CpuProfilerTrace.h"
#include "Stats/Stats.h"
#include "Stats/DynamicStats.h"
#include "Async/TaskGraphInterfaces.h"
#include "HAL/IConsoleManager.h"
#include "UObject/UObjectArray.h"
#include "TraceServices/ITraceServicesModule.h"
#include "TraceServices/AnalysisService.h"
#include "TraceServices/Model/AnalysisSession.h"
#include "TraceServices/Model/TimingProfiler.h"

namespace TickInspector
{
FPerformanceCapture::FPerformanceCapture()
{
    StartedHandle = FEditorDelegates::PostPIEStarted.AddRaw(this, &FPerformanceCapture::Started);
    EndedHandle = FEditorDelegates::PrePIEEnded.AddRaw(this, &FPerformanceCapture::Ended);
    FrameHandle = FWorldDelegates::OnWorldPreActorTick.AddRaw(this, &FPerformanceCapture::WorldFrame);
    Ticker = FTSTicker::GetCoreTicker().AddTicker(FTickerDelegate::CreateRaw(this, &FPerformanceCapture::Update));
}

FPerformanceCapture::~FPerformanceCapture()
{
    FEditorDelegates::PostPIEStarted.Remove(StartedHandle);
    FEditorDelegates::PrePIEEnded.Remove(EndedHandle);
    FWorldDelegates::OnWorldPreActorTick.Remove(FrameHandle);
    FTSTicker::GetCoreTicker().RemoveTicker(Ticker);
    if (GEditor && bPending) { GEditor->CancelRequestPlaySession(); }
    if (GEditor && bCapturing) { GEditor->RequestEndPlayMap(); }
    if (bOwnTrace) { FTraceAuxiliary::Stop(); }
    RestoreStats();
    if (Analysis) { Analysis->Stop(true); }
}

bool FPerformanceCapture::Start(double Seconds)
{
    if (IsBusy()) { return false; }
    if (!FMath::IsFinite(Seconds) || Seconds < 0.1 || Seconds > 600)
    { Message = TEXT("Capture duration must be between 0.1 and 600 seconds."); return false; }
    if (!GEditor || GEditor->IsPlaySessionInProgress())
    { Message = TEXT("Stop the existing play session before starting a measurement."); return false; }
    if (FTraceAuxiliary::IsConnected())
    { Message = TEXT("Another trace is recording. Stop that recording before starting a measurement."); return false; }
#if !STATS || !CPUPROFILERTRACE_ENABLED
    Message = TEXT("This editor build does not support UObject CPU timing capture.");
    return false;
#else
    Duration = Seconds;
    Report = FPerformanceReport(); ScopeToActor.Reset(); Actors.Reset();
    Message = TEXT("Starting PIE; the capture timer starts when PIE is ready.");
    bPending = true; RequestedAt = FPlatformTime::Seconds();
    // Dedicated settings avoid changing the user's normal Play mode or launching external clients.
    PlaySettings.Reset(NewObject<ULevelEditorPlaySettings>(GetTransientPackage()));
    ULevelEditorPlaySettings* Settings = PlaySettings.Get();
    Settings->SetPlayNumberOfClients(1);
    Settings->SetPlayNetMode(EPlayNetMode::PIE_Standalone);
    Settings->SetRunUnderOneProcess(true);
    FRequestPlaySessionParams Params;
    Params.EditorPlaySettings = Settings;
    GEditor->RequestPlaySession(Params);
    return true;
#endif
}

void FPerformanceCapture::Started(bool)
{
    if (!bPending) { return; }
    bPending = false;
    if (!GEditor || !GEditor->PlayWorld)
    { Message = TEXT("PIE did not create a local play world."); return; }
    if (FTraceAuxiliary::IsConnected())
    { Message = TEXT("A different trace started while PIE was launching; capture cancelled."); GEditor->RequestEndPlayMap(); return; }
    Report.TracePath = FPaths::ConvertRelativePathToFull(FPaths::ProjectSavedDir() / TEXT("TickInspector/Captures") /
        (FGuid::NewGuid().ToString(EGuidFormats::Digits) + TEXT(".utrace")));
    IFileManager::Get().MakeDirectory(*FPaths::GetPath(Report.TracePath), true);
#if STATS
    bPreviousObjectStats = !GET_STATID(STAT_UObjectsStatGroupTester).IsNone();
    IStatGroupEnableManager::Get().SetHighPerformanceEnableForGroup(TEXT("STATGROUP_UObjects"), true);
    auto Probe = FDynamicStats::CreateStatId<FStatGroup_STATGROUP_TaskGraphTasks>(FString(TEXT("TickInspector.TaskGroupProbe")));
    bPreviousTaskStats = !Probe.IsNone();
    IStatGroupEnableManager::Get().SetHighPerformanceEnableForGroup(TEXT("STATGROUP_TaskGraphTasks"), true);
    FThreadStats::PrimaryEnableAdd(1);
    ++GCycleStatsShouldEmitNamedEvents;
    bStatsEnabled = true;
    if (auto* Batching = IConsoleManager::Get().FindConsoleVariable(TEXT("tick.AllowBatchedTicks")))
    {
        Batching->Set(0, ECVF_SetByTemp, TEXT("TickInspector.Capture"));
        if (Batching->GetInt() != 0)
        {
            RestoreStats();
            Message = TEXT("Tick batching is forced on by a higher-priority console setting. Set tick.AllowBatchedTicks to 0 before capturing.");
            GEditor->RequestEndPlayMap(); return;
        }
    }
#endif
    FTraceAuxiliary::FOptions Options;
    Options.bExcludeTail = true;
    if (!FTraceAuxiliary::Start(FTraceAuxiliary::EConnectionType::File, *Report.TracePath, TEXT("cpu,frame"), &Options))
    { RestoreStats(); Message = TEXT("Could not start the CPU trace capture."); GEditor->RequestEndPlayMap(); return; }
    bOwnTrace = true; bCapturing = true; StartedAt = FPlatformTime::Seconds();
}

void FPerformanceCapture::WorldFrame(UWorld* World, ELevelTick, float)
{
    if (!bCapturing || !GEditor || World != GEditor->PlayWorld) { return; }
    TRACE_CPUPROFILER_EVENT_SCOPE_TEXT(TEXT("TickInspector.MeasurementFrame"));
    // Keep names and ownership while objects still exist, including streamed/spawned actors.
    // Full UObject stat descriptions distinguish identically named components and PIE worlds.
#if STATS
    for (TActorIterator<AActor> It(World); It; ++It)
    {
        AActor* Actor = *It;
        const FString ActorKey = TrackObject(Actor);
        if (!Actors.Contains(ActorKey))
        {
            FActorCost& Cost = Actors.Add(ActorKey);
            Cost.Path = Actor->GetPathName(); Cost.Label = Actor->GetActorNameOrLabel();
        }
        ScopeToActor.Add(ActorKey, ActorKey);
        TInlineComponentArray<UActorComponent*> Components(Actor);
        for (UActorComponent* Component : Components)
        { ScopeToActor.Add(TrackObject(Component), ActorKey); }
    }
#endif
}

FString FPerformanceCapture::TrackObject(UObject* Object)
{
#if STATS
    if (const FObjectStat* Existing = ObjectStats.Find(Object)) { return Existing->Scope; }
    FUObjectItem* Item = GUObjectArray.ObjectToObjectItem(Object);
    FObjectStat Saved;
    Saved.Previous = Item->StatID;
    // UE's default UObject stat names strip FName instance numbers, merging Actor_0
    // and Actor_1. Use capture-local unique stat identities, restored before PIE cleanup.
    // A nonnumeric suffix also prevents dynamic stat descriptions from dropping a
    // trailing FName number (Actor_0 -> Actor), which would break trace-name matching.
    Saved.Scope = TEXT("TickInspector.TickObject/") + FGuid::NewGuid().ToString(EGuidFormats::Digits) + TEXT(" ") + Object->GetPathName() + TEXT(" [tick]");
    Item->StatID = FDynamicStats::CreateStatId<FStatGroup_STATGROUP_UObjects>(Saved.Scope);
    Saved.Scope = Item->StatID.GetStatDescriptionWIDE();
    ObjectStats.Add(Object, Saved);
    return Saved.Scope;
#else
    return FString();
#endif
}

void FPerformanceCapture::RestoreStats()
{
#if STATS
    if (bStatsEnabled)
    {
        for (const auto& Entry : ObjectStats)
        {
            if (UObject* Object = Entry.Key.Get())
            { GUObjectArray.ObjectToObjectItem(Object)->StatID = Entry.Value.Previous; }
        }
        ObjectStats.Reset();
        --GCycleStatsShouldEmitNamedEvents;
        FThreadStats::PrimaryEnableSubtract(1);
        IStatGroupEnableManager::Get().SetHighPerformanceEnableForGroup(TEXT("STATGROUP_UObjects"), bPreviousObjectStats);
        IStatGroupEnableManager::Get().SetHighPerformanceEnableForGroup(TEXT("STATGROUP_TaskGraphTasks"), bPreviousTaskStats);
        if (auto* Batching = IConsoleManager::Get().FindConsoleVariable(TEXT("tick.AllowBatchedTicks")))
        { Batching->Unset(ECVF_SetByTemp, TEXT("TickInspector.Capture")); }
        bStatsEnabled = false;
    }
#endif
}

void FPerformanceCapture::Stop()
{
    if (bPending)
    { if (GEditor) { GEditor->CancelRequestPlaySession(); } bPending = false; Message = TEXT("PIE measurement cancelled before startup."); }
    if (bCapturing && GEditor) { GEditor->RequestEndPlayMap(); }
}

void FPerformanceCapture::Ended(bool)
{
    if (bCapturing) { FinishTrace(); }
    else if (bPending) { bPending = false; Message = TEXT("PIE startup was cancelled."); }
}

void FPerformanceCapture::FinishTrace()
{
    bCapturing = false;
    if (bOwnTrace) { FTraceAuxiliary::Stop(); bOwnTrace = false; }
    RestoreStats();
    auto& Module = FModuleManager::LoadModuleChecked<ITraceServicesModule>(TEXT("TraceServices"));
    Analysis = Module.GetAnalysisService()->StartAnalysis(*Report.TracePath);
    Message = TEXT("PIE stopped. Analyzing recorded CPU tick timings...");
    if (!Analysis) { Report.Error = TEXT("Could not analyze the recorded trace."); Message = Report.Error; if (OnResults) { OnResults(Report); } }
}

bool FPerformanceCapture::Update(float)
{
    if (bPending && FPlatformTime::Seconds() - RequestedAt > 120)
    { Stop(); Message = TEXT("PIE startup timed out; no measurements recorded."); }
    if (bCapturing && FPlatformTime::Seconds() - StartedAt >= Duration) { Stop(); }
    if (Analysis && Analysis->IsAnalysisComplete())
    {
        Analyze(); Analysis.Reset();
        Message = Report.Error.IsEmpty() ? TEXT("Measurement complete. Results show recorded CPU tick work, not predicted FPS savings.") : Report.Error;
        if (OnResults) { OnResults(Report); }
    }
    return true;
}

FString FPerformanceCapture::Status() const
{
    if (bCapturing) { return FString::Printf(TEXT("Recording PIE: %.1f / %.1f seconds. Stop PIE early to view results."), FPlatformTime::Seconds() - StartedAt, Duration); }
    return Message;
}

void FPerformanceCapture::Analyze()
{
    TraceServices::FAnalysisSessionReadScope ReadScope(*Analysis);
    const auto* Provider = TraceServices::ReadTimingProfilerProvider(*Analysis);
    if (!Provider) { Report.Error = TEXT("The trace contains no CPU timing data."); return; }
    const auto& Reader = Provider->GetTimerReader();
    struct FScope { FString Name; double Start; bool bMeasured = false; };
    Provider->EnumerateTimelines([&](const TraceServices::ITimingProfilerTimeline& Timeline)
    {
        TArray<FScope> Stack;
        Timeline.EnumerateEvents(0.0, Analysis->GetDurationSeconds(), [&](bool bStart, double Time, const TraceServices::FTimingProfilerEvent& Event)
        {
            if (bStart)
            {
                const auto* Timer = Reader.GetTimer(Event.TimerIndex);
                FString Name = Timer && Timer->Name ? Timer->Name : TEXT("");
                if (Name == TEXT("TickInspector.MeasurementFrame")) { ++Report.Frames; }
                const FString Parent = Stack.IsEmpty() ? FString() : Stack.Last().Name;
                // Only the outer UObject scope directly inside an engine tick execution is charged.
                // Nested Blueprint/function/object scopes must never be added a second time.
                bool bTick = Parent == TEXT("FTickFunctionTask") || Parent == TEXT("FBatchTickFunctionTask") ||
                    Parent == TEXT("FActorComponentTickFunction::ExecuteTick");
                bool bNestedMeasured = false;
                for (const auto& Scope : Stack) { bNestedMeasured |= Scope.bMeasured; }
                const bool bMapped = ScopeToActor.Contains(Name);
                if (bTick && !bMapped && Name.Contains(TEXT("UEDPIE_"))) { ++Report.UnattributedScopes; }
                Stack.Add({MoveTemp(Name), Time, bTick && bMapped && !bNestedMeasured});
            }
            else if (!Stack.IsEmpty())
            {
                FScope Scope = Stack.Pop(EAllowShrinking::No);
                if (Scope.bMeasured)
                {
                    FActorCost& Cost = Actors.FindChecked(ScopeToActor.FindChecked(Scope.Name));
                    const double Ms = FMath::Max(0.0, Time - Scope.Start) * 1000.0;
                    Cost.TotalMs += Ms; Cost.MaxTickMs = FMath::Max(Cost.MaxTickMs, Ms); ++Cost.Calls;
                }
            }
            return TraceServices::EEventEnumerate::Continue;
        });
    });
    Actors.GenerateValueArray(Report.Actors);
    Report.Actors.Sort([](const FActorCost& A, const FActorCost& B) { return A.TotalMs > B.TotalMs; });
    for (const auto& Actor : Report.Actors) { Report.TotalMs += Actor.TotalMs; }
    if (!Report.Frames) { Report.Error = TEXT("No PIE measurement frames were captured."); }
    else if (Report.TotalMs <= 0) { Report.Error = TEXT("No attributable tick timings found. No performance values can be inferred from this capture."); }
}
}
