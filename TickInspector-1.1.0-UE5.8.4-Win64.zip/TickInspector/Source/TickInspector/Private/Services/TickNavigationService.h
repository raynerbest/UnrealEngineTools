#pragma once
#include "Model/TickInspectorTypes.h"

namespace TickInspector
{
// Navigation always targets editor counterparts, never a guessed path match.
bool Navigate(const TArray<FRowPtr>& Rows, bool bFocus);
}
