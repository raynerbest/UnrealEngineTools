#pragma once
#include "Model/TickInspectorTypes.h"
class UCanvas;
class APlayerController;

namespace TickInspector
{
class FViewportVisualization
{
public:
    FViewportVisualization();
    ~FViewportVisualization();
    void Update(UWorld* InWorld, const TArray<FRowPtr>& Selection, bool bEnabled);
    static constexpr int32 MaxActors = 128;
private:
    void Draw(UCanvas* Canvas, APlayerController* Controller);
    FDelegateHandle DrawHandle;
    TWeakObjectPtr<UWorld> World;
    TArray<FBox> Boxes;
};
}
