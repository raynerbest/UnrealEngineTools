#include "TickCsvExporter.h"
#include "Misc/FileHelper.h"

namespace TickInspector
{
FString CsvCell(FString Value)
{
    // Prevent spreadsheet formula execution from object labels, keeping the source name intact in UE.
    FString Trimmed = Value.TrimStart();
    if (!Trimmed.IsEmpty() && (Trimmed[0] == '=' || Trimmed[0] == '+' || Trimmed[0] == '-' || Trimmed[0] == '@' || Value[0] == '\t' || Value[0] == '\r'))
    { Value = TEXT("'") + Value; }
    Value.ReplaceInline(TEXT("\""), TEXT("\"\""));
    return TEXT("\"") + Value + TEXT("\"");
}

FString Csv(const TArray<FRowPtr>& Rows, const FString& WorldName, const FString& Scope)
{
    FString Output = TEXT("World,Scope,CapturedUTC,ObjectPath,Actor,Object,Class,Kind,Level,CanEverTick,StartEnabled,EnabledNow,TickRegistered,ComponentRegistered,IntervalSeconds,ConfiguredGroup,ConfiguredEndGroup,Prerequisites,AnyThread,WhenPaused,OnDedicatedServer\r\n");
    for (const FRowPtr& Row : Rows)
    {
        if (!Row) { continue; }
        TArray<FString> Fields = {WorldName, Scope, Row->Captured.ToIso8601(), Row->Key, Row->ActorName, Row->Name, Row->ClassName,
            Row->bComponent ? TEXT("Component") : TEXT("Actor"), Row->Level,
            Row->bCanTick ? TEXT("true") : TEXT("false"), Row->bStartEnabled ? TEXT("true") : TEXT("false"),
            Row->bEnabled ? TEXT("true") : TEXT("false"), Row->bRegistered ? TEXT("true") : TEXT("false"),
            Row->bComponent ? (Row->bComponentRegistered ? TEXT("true") : TEXT("false")) : TEXT("N/A"),
            FString::Printf(TEXT("%.9g"), Row->Interval), GroupName(Row->Group), GroupName(Row->EndGroup),
            FString::FromInt(Row->Prerequisites), Row->bAnyThread ? TEXT("true") : TEXT("false"),
            Row->bPaused ? TEXT("true") : TEXT("false"), Row->bDedicatedServer ? TEXT("true") : TEXT("false")};
        for (int32 Index = 0; Index < Fields.Num(); ++Index)
        { if (Index) { Output += TEXT(","); } Output += CsvCell(Fields[Index]); }
        Output += TEXT("\r\n");
    }
    return Output;
}

bool ExportCsv(const FString& Filename, const TArray<FRowPtr>& Rows, const FString& WorldName, const FString& Scope)
{
    return FFileHelper::SaveStringToFile(Csv(Rows, WorldName, Scope), *Filename, FFileHelper::EEncodingOptions::ForceUTF8);
}
}
