#pragma once
#include "Model/TickInspectorTypes.h"
namespace TickInspector { FString Diagnostics(const FRow& Row); }
