#pragma once
#include "CoreMinimal.h"
#include "Containers/Ticker.h"
#include "Engine/EngineBaseTypes.h"
#include "UObject/StrongObjectPtr.h"
#include "Stats/Stats.h"
class ULevelEditorPlaySettings;
class SWindow;

namespace TraceServices { class IAnalysisSession; }
namespace TickInspector
{
struct FActorCost
{
    FString Path, Label;
    double TotalMs = 0, MaxTickMs = 0;
    uint64 Calls = 0;
};
struct FPerformanceReport
{
    TArray<FActorCost> Actors;
    FString TracePath, Error;
    double TotalMs = 0;
    uint64 Frames = 0, UnattributedScopes = 0;
};
TSharedRef<SWindow> ShowPerformanceResults(const FPerformanceReport& Report);

// Owns only the PIE and trace session explicitly started by this capture.
// Uses a core ticker, so the deadline also works when the inspector is hidden.
class FPerformanceCapture
{
public:
    FPerformanceCapture();
    ~FPerformanceCapture();
    bool Start(double Seconds);
    void Stop();
    bool IsBusy() const { return bPending || bCapturing || Analysis.IsValid(); }
    bool CanStop() const { return bPending || bCapturing; }
    FString Status() const;
    const FPerformanceReport& GetReport() const { return Report; }
    TFunction<void(const FPerformanceReport&)> OnResults;
private:
    bool Update(float);
    void Started(bool);
    void Ended(bool);
    void WorldFrame(UWorld*, ELevelTick, float);
    void FinishTrace();
    void Analyze();
    void RestoreStats();
    FString TrackObject(UObject* Object);
    FTSTicker::FDelegateHandle Ticker;
    FDelegateHandle StartedHandle, EndedHandle, FrameHandle;
    TSharedPtr<const TraceServices::IAnalysisSession> Analysis;
    TMap<FString, FString> ScopeToActor;
    TMap<FString, FActorCost> Actors;
    FPerformanceReport Report;
    FString Message;
    double Duration = 10, RequestedAt = 0, StartedAt = 0;
    bool bPending = false, bCapturing = false, bOwnTrace = false, bStatsEnabled = false;
    bool bPreviousObjectStats = false;
    bool bPreviousTaskStats = false;
#if STATS
    struct FObjectStat { TStatId Previous; FString Scope; };
    TMap<TWeakObjectPtr<UObject>, FObjectStat> ObjectStats;
#endif
    TStrongObjectPtr<ULevelEditorPlaySettings> PlaySettings;
};
}
