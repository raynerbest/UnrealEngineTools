#include "TickNavigationService.h"
#include "Editor.h"
#include "Engine/World.h"
#include "GameFramework/Actor.h"

namespace TickInspector
{
bool Navigate(const TArray<FRowPtr>& Rows, bool bFocus)
{
    if (!GEditor || GEditor->IsTransactionActive()) { return false; }
    TArray<AActor*> Actors;
    for (const FRowPtr& Row : Rows)
    {
        AActor* Actor = Row ? Row->Owner.Get() : nullptr;
        if (!IsValid(Actor) || Actor->IsActorBeingDestroyed()) { continue; }
        if (Actor->GetWorld()->WorldType == EWorldType::PIE) { Actor = EditorUtilities::GetEditorWorldCounterpartActor(Actor); }
        if (Actor && Actor->GetWorld()->WorldType == EWorldType::Editor && GEditor->CanSelectActor(Actor, true)) { Actors.AddUnique(Actor); }
    }
    if (Actors.IsEmpty()) { return false; }
    GEditor->SelectNone(false, true, false);
    for (AActor* Actor : Actors) { GEditor->SelectActor(Actor, true, false); }
    GEditor->NoteSelectionChange();
    if (bFocus) { GEditor->MoveViewportCamerasToActor(Actors, true); }
    return true;
}
}
