#include "TickDiagnostics.h"

namespace TickInspector
{
FString Diagnostics(const FRow& Row)
{
    TArray<FString> Notes;
    if (!FMath::IsFinite(Row.Interval)) { Notes.Add(TEXT("Warning: interval is not finite.")); }
    else if (Row.Interval < 0) { Notes.Add(TEXT("Negative interval: the engine treats intervals <= 0 as every eligible frame; inspector input accepts nonnegative values.")); }
    if (!Row.bCanTick && Row.bRegistered) { Notes.Add(TEXT("Review: registered tick currently has capability disabled.")); }
    if (Row.Prerequisites) { Notes.Add(TEXT("Dependencies may delay execution beyond the configured group.")); }
    if (Row.bEnabled != Row.bStartEnabled) { Notes.Add(TEXT("Current enabled state differs from startup configuration.")); }
    if (!Row.bRegistered) { Notes.Add(TEXT("Not registered with the tick scheduler; this can be normal in editor worlds or during lifecycle transitions.")); }
    if (!Row.Object.IsValid()) { Notes.Add(TEXT("Object expired since this snapshot; rescan.")); }
    return Notes.IsEmpty() ? TEXT("No configuration observations. Cost is not measured.") : FString::Join(Notes, TEXT(" "));
}
}
