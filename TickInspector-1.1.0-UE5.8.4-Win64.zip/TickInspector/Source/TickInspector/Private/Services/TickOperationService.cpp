#include "TickOperationService.h"
#include "Editor.h"
#include "Engine/World.h"
#include "GameFramework/Actor.h"
#include "Components/ActorComponent.h"
#include "LevelUtils.h"
#include "ScopedTransaction.h"
#include "UObject/UnrealType.h"
#include "UObject/Package.h"
#include "UObject/ObjectKey.h"

namespace TickInspector
{
FString FEditResult::Summary() const
{
    FString Text = FString::Printf(TEXT("Changed: %d | Unchanged: %d | Skipped: %d"), Changed, Unchanged, Skipped);
    for (const FString& Reason : Reasons) { Text += TEXT("\n") + Reason; }
    return Text;
}

bool IsUserGroup(ETickingGroup Group)
{ return Group == TG_PrePhysics || Group == TG_DuringPhysics || Group == TG_PostPhysics || Group == TG_PostUpdateWork; }

FString EditEligibility(UObject* Object, UWorld* ExpectedWorld, bool bPersistent)
{
    if (!IsValid(Object) || Object->IsTemplate() || !IsValid(ExpectedWorld) || Object->GetWorld() != ExpectedWorld)
    { return TEXT("Stale object, template, or world mismatch."); }
    FTickFunction* Tick = ResolveTick(Object);
    if (!Tick) { return TEXT("No supported primary tick."); }
    UActorComponent* Component = Cast<UActorComponent>(Object);
    AActor* Actor = Component ? Component->GetOwner() : Cast<AActor>(Object);
    if (!IsValid(Actor) || Actor->IsActorBeingDestroyed()) { return TEXT("The owning actor is being destroyed."); }
    if (!bPersistent)
    {
        return ExpectedWorld->WorldType == EWorldType::PIE ? FString() : TEXT("Session operations require a PIE world.");
    }
    if (ExpectedWorld->WorldType != EWorldType::Editor) { return TEXT("Persistent edits require an editor world."); }
    if (GEditor && GEditor->PlayWorld) { return TEXT("Stop PIE before editing persistent configuration."); }
    if (Object->HasAnyFlags(RF_Transient) || Actor->HasAnyFlags(RF_Transient)) { return TEXT("Transient objects cannot retain saved configuration."); }
    if (!Object->HasAnyFlags(RF_Transactional) || !Actor->HasAnyFlags(RF_Transactional)) { return TEXT("Object does not support editor transactions."); }
    if (FLevelUtils::IsLevelLocked(Actor->GetLevel())) { return TEXT("The owning level is locked."); }
    if (Component && Component->CreationMethod != EComponentCreationMethod::Instance && Component->CreationMethod != EComponentCreationMethod::Native)
    { return TEXT("Construction-script components must be configured in their Blueprint defaults; reconstruction may discard instance overrides."); }
    return FString();
}

FEditResult Apply(const TArray<FRowPtr>& Rows, UWorld* ExpectedWorld, const FEdit& Edit, bool bPersistent)
{
    check(IsInGameThread());
    FEditResult Result;
    if ((!Edit.Enabled.IsSet() && !Edit.Interval.IsSet() && !Edit.Group.IsSet()) ||
        (Edit.Interval.IsSet() && (!FMath::IsFinite(Edit.Interval.GetValue()) || Edit.Interval.GetValue() < 0)) ||
        (Edit.Group.IsSet() && !IsUserGroup(Edit.Group.GetValue())) || (GEditor && GEditor->IsTransactionActive()))
    {
        Result.Skipped = Rows.Num();
        Result.Reasons.Add(TEXT("Invalid edit or another transaction is active. Intervals must be finite and nonnegative; internal tick groups are not editable."));
        return Result;
    }
    // Preflight each item before the transaction. A rejection never loads an actor or modifies an archetype.
    TArray<TWeakObjectPtr<UObject>> Targets;
    TSet<FObjectKey> Seen;
    auto Skip = [&Result](const FString& Name, const FString& Reason)
    {
        ++Result.Skipped;
        if (Result.Reasons.Num() < 8) { Result.Reasons.Add(Name + TEXT(": ") + Reason); }
    };
    for (const auto& Row : Rows)
    {
        UObject* Object = Row ? Row->Object.Get() : nullptr;
        if (Object && Seen.Contains(FObjectKey(Object))) { continue; }
        if (Object) { Seen.Add(FObjectKey(Object)); }
        FString Reason = EditEligibility(Object, ExpectedWorld, bPersistent);
        if (!Reason.IsEmpty()) { Skip(Row ? Row->Name : TEXT("Missing row"), Reason); continue; }
        FTickFunction* Tick = ResolveTick(Object);
        if (Edit.Enabled.IsSet() && Edit.Enabled.GetValue() && !Tick->bCanEverTick)
        { Skip(Row->Name, TEXT("Tick capability is false. The inspector does not force bCanEverTick.")); continue; }
        const bool bSame = (!Edit.Enabled.IsSet() || (bPersistent ? bool(Tick->bStartWithTickEnabled) : Tick->IsTickFunctionEnabled()) == Edit.Enabled.GetValue()) &&
            (!Edit.Interval.IsSet() || Tick->TickInterval == Edit.Interval.GetValue()) &&
            (!Edit.Group.IsSet() || Tick->TickGroup == Edit.Group.GetValue());
        if (bSame) { ++Result.Unchanged; continue; }
        Targets.Add(Object);
    }
    if (Targets.IsEmpty()) { return Result; }
    FScopedTransaction Transaction(NSLOCTEXT("TickInspector", "EditTransaction", "Edit primary Tick configuration"), bPersistent);
    for (TWeakObjectPtr<UObject> Target : Targets)
    {
        UObject* Object = Target.Get();
        FString Reason = EditEligibility(Object, ExpectedWorld, bPersistent);
        if (!Reason.IsEmpty()) { Skip(GetNameSafe(Object), Reason); continue; }
        FTickFunction* Tick = ResolveTick(Object);
        UActorComponent* Component = Cast<UActorComponent>(Object);
        AActor* Actor = Component ? Component->GetOwner() : Cast<AActor>(Object);
        TWeakObjectPtr<AActor> WeakOwner = Actor;
        FProperty* Property = FindFProperty<FProperty>(Object->GetClass(), Component ? TEXT("PrimaryComponentTick") : TEXT("PrimaryActorTick"));
        if (bPersistent)
        {
            Object->Modify();
            if (Component) { Actor->Modify(); }
            Object->PreEditChange(Property);
            Object = Target.Get();
            Tick = ResolveTick(Object);
            if (!Tick) { Skip(TEXT("Reconstructed object"), TEXT("Object changed during pre-edit notification; rescan and retry.")); continue; }
            // These are reflected configuration fields. Internal scheduler state is not serialized.
            if (Edit.Enabled.IsSet()) { Tick->bStartWithTickEnabled = Edit.Enabled.GetValue(); }
            if (Edit.Interval.IsSet()) { Tick->TickInterval = Edit.Interval.GetValue(); }
            if (Edit.Group.IsSet()) { Tick->TickGroup = Edit.Group.GetValue(); }
            FPropertyChangedEvent Event(Property, EPropertyChangeType::ValueSet);
            Object->PostEditChangeProperty(Event);
            // PostEditChangeProperty can reconstruct components; never access Tick/Object afterwards.
            if (AActor* LiveOwner = WeakOwner.Get())
            {
                LiveOwner->MarkPackageDirty();
                if (UPackage* External = LiveOwner->GetExternalPackage()) { External->MarkPackageDirty(); }
            }
        }
        else
        {
            if (Edit.Enabled.IsSet())
            {
                if (Component) { Component->SetComponentTickEnabled(Edit.Enabled.GetValue()); }
                else { Actor->SetActorTickEnabled(Edit.Enabled.GetValue()); }
            }
            if (Edit.Interval.IsSet()) { Tick->UpdateTickIntervalAndCoolDown(Edit.Interval.GetValue()); }
            if (Edit.Group.IsSet())
            {
                if (Component) { Component->SetTickGroup(Edit.Group.GetValue()); }
                else { Actor->SetTickGroup(Edit.Group.GetValue()); }
            }
        }
        ++Result.Changed;
    }
    if (bPersistent && !Result.Changed) { Transaction.Cancel(); }
    return Result;
}
}
