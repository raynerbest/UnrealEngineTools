#pragma once
#include "Model/TickInspectorTypes.h"

namespace TickInspector
{
FString CsvCell(FString Value);
FString Csv(const TArray<FRowPtr>& Rows, const FString& WorldName, const FString& Scope);
bool ExportCsv(const FString& Filename, const TArray<FRowPtr>& Rows, const FString& WorldName, const FString& Scope);
}
