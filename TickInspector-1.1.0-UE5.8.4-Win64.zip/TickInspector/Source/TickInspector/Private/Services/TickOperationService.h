#pragma once
#include "Model/TickInspectorTypes.h"

namespace TickInspector
{
struct FEdit
{
    TOptional<bool> Enabled;
    TOptional<float> Interval;
    TOptional<ETickingGroup> Group;
};
struct FEditResult
{
    int32 Changed = 0, Unchanged = 0, Skipped = 0;
    TArray<FString> Reasons;
    FString Summary() const;
};
bool IsUserGroup(ETickingGroup Group);
FString EditEligibility(UObject* Object, UWorld* ExpectedWorld, bool bPersistent);
FEditResult Apply(const TArray<FRowPtr>& Rows, UWorld* ExpectedWorld, const FEdit& Edit, bool bPersistent);
}
