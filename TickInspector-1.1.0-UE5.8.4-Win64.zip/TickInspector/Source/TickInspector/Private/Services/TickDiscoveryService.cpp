#include "TickDiscoveryService.h"
#include "Editor.h"
#include "Engine/Engine.h"
#include "Engine/Level.h"
#include "Engine/World.h"
#include "GameFramework/Actor.h"
#include "Components/ActorComponent.h"
#include "UObject/UObjectGlobals.h"

namespace TickInspector
{
FTickFunction* ResolveTick(UObject* Object)
{
    if (!IsValid(Object) || Object->IsTemplate()) { return nullptr; }
    if (AActor* Actor = Cast<AActor>(Object)) { return &Actor->PrimaryActorTick; }
    if (UActorComponent* Component = Cast<UActorComponent>(Object)) { return &Component->PrimaryComponentTick; }
    return nullptr;
}

FString GroupName(ETickingGroup Group)
{
    return StaticEnum<ETickingGroup>()->GetDisplayNameTextByValue(Group).ToString();
}

FRowPtr Capture(UObject* Object)
{
    FTickFunction* Tick = ResolveTick(Object);
    if (!Tick) { return nullptr; }
    UActorComponent* Component = Cast<UActorComponent>(Object);
    AActor* Actor = Component ? Component->GetOwner() : Cast<AActor>(Object);
    if (!IsValid(Actor) || Actor->IsActorBeingDestroyed()) { return nullptr; }
    FRowPtr Row = MakeShared<FRow>();
    Row->Object = Object;
    Row->Owner = Actor;
    Row->Key = Object->GetPathName();
    Row->ActorName = Actor->GetActorNameOrLabel();
    Row->Name = Component ? Component->GetName() : Row->ActorName;
    Row->ClassName = Object->GetClass()->GetName();
    Row->Level = Actor->GetLevel()->GetOutermost()->GetName();
    Row->bComponent = Component != nullptr;
    Row->bCanTick = Tick->bCanEverTick;
    Row->bStartEnabled = Tick->bStartWithTickEnabled;
    Row->bEnabled = Tick->IsTickFunctionEnabled();
    Row->bRegistered = Tick->IsTickFunctionRegistered();
    Row->bComponentRegistered = Component && Component->IsRegistered();
    Row->Interval = Tick->TickInterval;
    Row->Group = Tick->TickGroup;
    Row->EndGroup = Tick->EndTickGroup;
    Row->Prerequisites = Tick->GetPrerequisites().Num();
    Row->bAnyThread = Tick->bRunOnAnyThread;
    Row->bPaused = Tick->bTickEvenWhenPaused;
    Row->bDedicatedServer = Tick->bAllowTickOnDedicatedServer;
    Row->Captured = FDateTime::UtcNow();
    Row->SearchText = (Row->ActorName + TEXT(" ") + Row->Name + TEXT(" ") + Row->ClassName + TEXT(" ") +
        Row->Level + TEXT(" ") + Row->Key + TEXT(" ") + GroupName(Row->Group)).ToLower();
    return Row;
}

TArray<TSharedPtr<FWorldChoice>> FDiscoveryService::Worlds()
{
    TArray<TSharedPtr<FWorldChoice>> Result;
    if (!GEngine) { return Result; }
    for (const FWorldContext& Context : GEngine->GetWorldContexts())
    {
        UWorld* World = Context.World();
        if (!IsValid(World) || (Context.WorldType != EWorldType::Editor && Context.WorldType != EWorldType::PIE)) { continue; }
        TSharedPtr<FWorldChoice> Choice = MakeShared<FWorldChoice>();
        Choice->World = World;
        Choice->Label = Context.WorldType == EWorldType::Editor
            ? FString::Printf(TEXT("Editor | %s"), *World->GetName())
            : FString::Printf(TEXT("PIE %d | %s | %s"), Context.PIEInstance,
                World->GetNetMode() == NM_Client ? TEXT("Client") : World->GetNetMode() == NM_Standalone ? TEXT("Standalone") : TEXT("Server"), *World->GetName());
        Result.Add(Choice);
    }
    Result.Sort([](const auto& A, const auto& B) { return A->Label < B->Label; });
    return Result;
}

FDiscoveryService::FDiscoveryService()
{
    if (GEditor) { GEditor->RegisterForUndo(this); }
    CleanupHandle = FWorldDelegates::OnWorldCleanup.AddRaw(this, &FDiscoveryService::ClearWorld);
    auto LevelChange = [this](ULevel*, UWorld* ChangedWorld) { if (ChangedWorld == World.Get()) { RequestScan(); } };
    LevelAddedHandle = FWorldDelegates::LevelAddedToWorld.AddLambda(LevelChange);
    LevelRemovedHandle = FWorldDelegates::LevelRemovedFromWorld.AddLambda(LevelChange);
    PropertyHandle = FCoreUObjectDelegates::OnObjectPropertyChanged.AddLambda(
        [this](UObject* Object, FPropertyChangedEvent&) { if (Object && Object->GetWorld() == World.Get()) { RequestScan(); } });
    ReplacedHandle = FCoreUObjectDelegates::OnObjectsReplaced.AddLambda(
        [this](const auto&) { RequestScan(); });
}

FDiscoveryService::~FDiscoveryService()
{
    if (GEditor) { GEditor->UnregisterForUndo(this); }
    FWorldDelegates::OnWorldCleanup.Remove(CleanupHandle);
    FWorldDelegates::LevelAddedToWorld.Remove(LevelAddedHandle);
    FWorldDelegates::LevelRemovedFromWorld.Remove(LevelRemovedHandle);
    FCoreUObjectDelegates::OnObjectPropertyChanged.Remove(PropertyHandle);
    FCoreUObjectDelegates::OnObjectsReplaced.Remove(ReplacedHandle);
}

void FDiscoveryService::ClearWorld(UWorld* InWorld, bool, bool)
{
    if (World.Get() == InWorld) { SetWorld(nullptr); }
}

void FDiscoveryService::SetWorld(UWorld* InWorld)
{
    Cancel();
    World = InWorld;
    Rows.Empty();
    ++Revision;
    bRequested = true;
}

void FDiscoveryService::Cancel()
{
    bScanning = false;
    bRequested = false;
    Pending.Empty();
    Components.Empty();
    Levels.Empty();
    Seen.Empty();
    NextScan = FPlatformTime::Seconds() + 2.0;
}

void FDiscoveryService::BeginScan()
{
    UWorld* Current = World.Get();
    if (!Current) { return; }
    Pending.Reset(); Components.Reset(); Levels.Reset(); Seen.Reset();
    for (ULevel* Level : Current->GetLevels()) { Levels.Add(Level); }
    LevelIndex = ActorIndex = ComponentIndex = Visited = 0;
    bScanning = true;
    bRequested = false;
}

void FDiscoveryService::Update()
{
    check(IsInGameThread());
    if (!World.IsValid())
    {
        if (!Rows.IsEmpty() || bScanning) { SetWorld(nullptr); }
        return;
    }
    const double Now = FPlatformTime::Seconds();
    if (!bScanning && (bRequested || Now >= NextScan)) { BeginScan(); }
    const double Deadline = FPlatformTime::Seconds() + 0.002;
    while (bScanning && FPlatformTime::Seconds() < Deadline)
    {
        UObject* Object = nullptr;
        if (ComponentIndex < Components.Num()) { Object = Components[ComponentIndex++].Get(); }
        else
        {
            Components.Reset(); ComponentIndex = 0;
            if (LevelIndex >= Levels.Num())
            {
                Rows = MoveTemp(Pending);
                bScanning = false;
                ++Revision;
                NextScan = FPlatformTime::Seconds() + 2.0;
                break;
            }
            ULevel* Level = Levels[LevelIndex].Get();
            if (!Level || ActorIndex >= Level->Actors.Num()) { ++LevelIndex; ActorIndex = 0; continue; }
            AActor* Actor = Level->Actors[ActorIndex++];
            if (!IsValid(Actor) || Actor->GetWorld() != World.Get() || Actor->IsActorBeingDestroyed()) { continue; }
            Object = Actor;
            TInlineComponentArray<UActorComponent*> ActorComponents(Actor);
            for (UActorComponent* Component : ActorComponents) { Components.Add(Component); }
        }
        ++Visited;
        if (IsValid(Object) && Object->GetWorld() == World.Get())
        {
            if (FRowPtr Row = Capture(Object); Row && !Seen.Contains(Row->Key))
            {
                Seen.Add(Row->Key);
                Pending.Add(Row);
            }
        }
    }
}
}
