#pragma once
#include "Model/TickInspectorTypes.h"
#include "EditorUndoClient.h"
#include <atomic>

class ULevel;

namespace TickInspector
{
class FDiscoveryService : public FEditorUndoClient
{
public:
    FDiscoveryService();
    virtual ~FDiscoveryService() override;
    static TArray<TSharedPtr<FWorldChoice>> Worlds();
    void SetWorld(UWorld* InWorld);
    UWorld* GetWorld() const { return World.Get(); }
    void RequestScan() { bRequested = true; }
    void Cancel();
    void Update();
    bool IsScanning() const { return bScanning; }
    int32 GetVisited() const { return Visited; }
    uint64 GetRevision() const { return Revision; }
    const TArray<FRowPtr>& GetRows() const { return Rows; }
    virtual void PostUndo(bool bSuccess) override { RequestScan(); }
    virtual void PostRedo(bool bSuccess) override { RequestScan(); }
private:
    void BeginScan();
    void ClearWorld(UWorld* InWorld, bool bSessionEnded, bool bCleanupResources);
    TWeakObjectPtr<UWorld> World;
    TArray<TWeakObjectPtr<ULevel>> Levels;
    TArray<TWeakObjectPtr<UActorComponent>> Components;
    TArray<FRowPtr> Rows, Pending;
    TSet<FString> Seen;
    int32 LevelIndex = 0, ActorIndex = 0, ComponentIndex = 0, Visited = 0;
    uint64 Revision = 0;
    bool bScanning = false;
    std::atomic<bool> bRequested{true};
    double NextScan = 0;
    FDelegateHandle CleanupHandle, LevelAddedHandle, LevelRemovedHandle, PropertyHandle, ReplacedHandle;
};
}
