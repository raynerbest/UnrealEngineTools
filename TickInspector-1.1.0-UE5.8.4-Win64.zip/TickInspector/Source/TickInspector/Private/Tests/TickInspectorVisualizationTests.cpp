#if WITH_DEV_AUTOMATION_TESTS
#include "Misc/AutomationTest.h"
#include "Services/TickDiagnostics.h"
#include "Services/TickViewportVisualization.h"
#include "Services/TickDiscoveryService.h"
#include "Engine/World.h"
#include "Engine/Engine.h"
#include "GameFramework/Actor.h"
#include "GameFramework/WorldSettings.h"
#include "WorldPartition/WorldPartition.h"
#include "Components/StaticMeshComponent.h"

using namespace TickInspector;

IMPLEMENT_SIMPLE_AUTOMATION_TEST(FTickInspectorVisualizationTest, "TickInspector.Visualization.NonDestructiveBounds",
    EAutomationTestFlags::EditorContext | EAutomationTestFlags::EngineFilter)

bool FTickInspectorVisualizationTest::RunTest(const FString& Parameters)
{
    UWorld* World = UWorld::CreateWorld(EWorldType::Editor, false);
    GEngine->CreateNewWorldContext(EWorldType::Editor).SetCurrentWorld(World);
    AActor* Actor = World->SpawnActor<AActor>();
    UStaticMeshComponent* Component = NewObject<UStaticMeshComponent>(Actor);
    Actor->AddInstanceComponent(Component);
    Actor->SetRootComponent(Component);
    Component->RegisterComponent();
    Component->SetRenderCustomDepth(false);
    const FTransform Before = Actor->GetActorTransform();
    UMaterialInterface* Material = Component->GetMaterial(0);
    const bool bDirty = Actor->GetPackage()->IsDirty();
    {
        FViewportVisualization View;
        View.Update(World, {Capture(Actor), Capture(Component)}, true);
        TestFalse(TEXT("Highlight leaves custom depth untouched"), bool(Component->bRenderCustomDepth));
        TestTrue(TEXT("Highlight leaves transform untouched"), Actor->GetActorTransform().Equals(Before));
        TestTrue(TEXT("Highlight leaves material untouched"), Component->GetMaterial(0) == Material);
        TestEqual(TEXT("Highlight leaves package dirty state untouched"), Actor->GetPackage()->IsDirty(), bDirty);
        View.Update(nullptr, {}, false);
    }
    FRow Row;
    Row.bRegistered = false; Row.Interval = 0;
    TestFalse(TEXT("Unregistered state is not declared expensive"), Diagnostics(Row).Contains(TEXT("expensive")));
    TestTrue(TEXT("Editor lifecycle caveat is explained"), Diagnostics(Row).Contains(TEXT("normal in editor")));
    Row.Interval = -1;
    TestTrue(TEXT("Negative interval uses actual engine semantics"), Diagnostics(Row).Contains(TEXT("engine treats intervals <= 0")));
    World->DestroyWorld(false);
    GEngine->DestroyWorldContext(World);
    return true;
}

IMPLEMENT_SIMPLE_AUTOMATION_TEST(FTickInspectorPartitionTest, "TickInspector.WorldPartition.LoadedActorsWithoutLoadingCells",
    EAutomationTestFlags::EditorContext | EAutomationTestFlags::EngineFilter)

bool FTickInspectorPartitionTest::RunTest(const FString& Parameters)
{
    UWorld* World = UWorld::CreateWorld(EWorldType::Editor, false);
    GEngine->CreateNewWorldContext(EWorldType::Editor).SetCurrentWorld(World);
    UWorldPartition* Partition = UWorldPartition::CreateOrRepairWorldPartition(World->GetWorldSettings());
    TestNotNull(TEXT("World Partition exists"), Partition);
    AActor* Actor = World->SpawnActor<AActor>();
    FDiscoveryService Discovery;
    Discovery.SetWorld(World); Discovery.Update();
    for (int32 Step = 0; Discovery.IsScanning() && Step < 10000; ++Step) { Discovery.Update(); }
    TestTrue(TEXT("Loaded actor is discovered in a partitioned world"), Discovery.GetRows().ContainsByPredicate(
        [Actor](const FRowPtr& Row) { return Row->Object.Get() == Actor; }));
    TestTrue(TEXT("Scan preserves World Partition object"), World->GetWorldPartition() == Partition);
    World->DestroyWorld(false);
    GEngine->DestroyWorldContext(World);
    return true;
}
#endif
