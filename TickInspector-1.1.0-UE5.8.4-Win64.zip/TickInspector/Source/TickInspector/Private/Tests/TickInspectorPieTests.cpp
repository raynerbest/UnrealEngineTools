#if WITH_DEV_AUTOMATION_TESTS
#include "Misc/AutomationTest.h"
#include "Tests/AutomationEditorCommon.h"
#include "Services/TickDiscoveryService.h"
#include "Services/TickOperationService.h"
#include "Editor.h"
#include "Engine/World.h"
#include "EngineUtils.h"
#include "GameFramework/Actor.h"

using namespace TickInspector;
namespace
{
struct FSessionState
{
    TWeakObjectPtr<AActor> EditorActor;
    TSharedPtr<FDiscoveryService> Discovery;
};

class FInspectActualPie : public IAutomationLatentCommand
{
public:
    FInspectActualPie(FAutomationTestBase* InTest, TSharedPtr<FSessionState> InState) : Test(InTest), State(InState) {}
    virtual bool Update() override
    {
        if (!Started) { Started = FPlatformTime::Seconds(); }
        UWorld* Pie = GEditor->PlayWorld;
        if (!Pie && FPlatformTime::Seconds() - Started < 20.0) { return false; }
        if (!Test->TestNotNull(TEXT("Actual PIE world started"), Pie)) { return true; }
        AActor* Actor = nullptr;
        for (TActorIterator<AActor> It(Pie); It; ++It)
        { if (State->EditorActor.IsValid() && It->GetFName() == State->EditorActor->GetFName()) { Actor = *It; break; } }
        if (!Test->TestNotNull(TEXT("Actor duplicated into PIE"), Actor)) { return true; }
        Test->TestTrue(TEXT("World picker enumerates actual PIE context"), FDiscoveryService::Worlds().ContainsByPredicate(
            [Pie](const auto& Choice) { return Choice->World.Get() == Pie; }));
        Test->TestTrue(TEXT("PIE primary tick registered"), Actor->PrimaryActorTick.IsTickFunctionRegistered());
        FEdit Edit; Edit.Enabled = true; Edit.Interval = 0.3f;
        Test->TestEqual(TEXT("Actual PIE edit succeeds"), Apply({Capture(Actor)}, Pie, Edit, false).Changed, 1);
        Test->TestTrue(TEXT("Actual PIE runtime state enabled"), Actor->IsActorTickEnabled());
        Test->TestFalse(TEXT("Editor startup flag remains disabled"), bool(State->EditorActor->PrimaryActorTick.bStartWithTickEnabled));
        Test->TestEqual(TEXT("PIE does not alter editor interval"), State->EditorActor->PrimaryActorTick.TickInterval, 0.125f);
        Test->TestTrue(TEXT("Navigation counterpart is exact original"), EditorUtilities::GetEditorWorldCounterpartActor(Actor) == State->EditorActor.Get());
        State->Discovery = MakeShared<FDiscoveryService>();
        State->Discovery->SetWorld(Pie); State->Discovery->Update();
        return true;
    }
private:
    FAutomationTestBase* Test;
    TSharedPtr<FSessionState> State;
    double Started = 0;
};

class FCheckPieEnded : public IAutomationLatentCommand
{
public:
    FCheckPieEnded(FAutomationTestBase* InTest, TSharedPtr<FSessionState> InState) : Test(InTest), State(InState) {}
    virtual bool Update() override
    {
        if (!Started) { Started = FPlatformTime::Seconds(); }
        if (GEditor->PlayWorld && FPlatformTime::Seconds() - Started < 10.0) { return false; }
        Test->TestNull(TEXT("PIE ended"), GEditor->PlayWorld);
        if (State->Discovery)
        {
            Test->TestNull(TEXT("Inspector releases cleaned PIE world"), State->Discovery->GetWorld());
            Test->TestEqual(TEXT("Inspector clears PIE rows"), State->Discovery->GetRows().Num(), 0);
        }
        if (AActor* Actor = State->EditorActor.Get())
        {
            Test->TestEqual(TEXT("Editor interval still unchanged after PIE"), Actor->PrimaryActorTick.TickInterval, 0.125f);
            Actor->GetWorld()->DestroyActor(Actor);
        }
        State->Discovery.Reset();
        return true;
    }
private:
    FAutomationTestBase* Test;
    TSharedPtr<FSessionState> State;
    double Started = 0;
};
}

IMPLEMENT_SIMPLE_AUTOMATION_TEST(FTickInspectorActualPieTest, "TickInspector.Session.ActualPieLifecycle",
    EAutomationTestFlags::EditorContext | EAutomationTestFlags::EngineFilter)

bool FTickInspectorActualPieTest::RunTest(const FString& Parameters)
{
    if (GEditor->PlayWorld) { AddError(TEXT("Stop PIE before running this isolated-host test.")); return false; }
    UWorld* World = FAutomationEditorCommonUtils::CreateNewMap();
    AActor* Actor = World->SpawnActor<AActor>();
    Actor->PrimaryActorTick.bCanEverTick = true;
    Actor->PrimaryActorTick.bStartWithTickEnabled = false;
    Actor->PrimaryActorTick.TickInterval = 0.125f;
    Actor->SetActorTickEnabled(false);
    TSharedPtr<FSessionState> State = MakeShared<FSessionState>();
    State->EditorActor = Actor;
    ADD_LATENT_AUTOMATION_COMMAND(FStartPIECommand(false));
    ADD_LATENT_AUTOMATION_COMMAND(FInspectActualPie(this, State));
    ADD_LATENT_AUTOMATION_COMMAND(FEndPlayMapCommand());
    ADD_LATENT_AUTOMATION_COMMAND(FCheckPieEnded(this, State));
    return true;
}
#endif
