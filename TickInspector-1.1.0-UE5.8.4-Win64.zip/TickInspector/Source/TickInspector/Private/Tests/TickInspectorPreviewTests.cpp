#if WITH_DEV_AUTOMATION_TESTS
#include "Misc/AutomationTest.h"
#include "Tests/AutomationCommon.h"
#include "Misc/App.h"
#include "Misc/FileHelper.h"
#include "Misc/Paths.h"
#include "ImageUtils.h"
#include "Framework/Application/SlateApplication.h"
#include "Framework/Docking/TabManager.h"
#include "Widgets/Docking/SDockTab.h"
#include "HAL/FileManager.h"

namespace
{
class FCaptureTickInspector : public IAutomationLatentCommand
{
public:
    FCaptureTickInspector(FAutomationTestBase* InTest, TSharedPtr<SDockTab> InTab) : Test(InTest), Tab(InTab) {}
    virtual bool Update() override
    {
        TArray<FColor> Pixels;
        FIntVector Size(0, 0, 0);
        const bool bCaptured = Tab && FSlateApplication::Get().TakeScreenshot(Tab->GetContent(), Pixels, Size);
        Test->TestTrue(TEXT("Slate inspector screenshot captured"), bCaptured);
        if (bCaptured)
        {
            const FString Directory = FPaths::ProjectSavedDir() / TEXT("TickInspectorTests");
            IFileManager::Get().MakeDirectory(*Directory, true);
            TArray64<uint8> Png;
            FImageUtils::PNGCompressImageArray(Size.X, Size.Y, TArrayView64<const FColor>(Pixels.GetData(), Pixels.Num()), Png);
            Test->TestTrue(TEXT("Preview PNG saved"), FFileHelper::SaveArrayToFile(Png, *(Directory / TEXT("Inspector.png"))));
        }
        if (Tab) { Tab->RequestCloseTab(); }
        return true;
    }
private:
    FAutomationTestBase* Test;
    TSharedPtr<SDockTab> Tab;
};
}

IMPLEMENT_SIMPLE_AUTOMATION_TEST(FTickInspectorPreviewTest, "TickInspector.Preview.EditorScreenshot",
    EAutomationTestFlags::EditorContext | EAutomationTestFlags::EngineFilter)

bool FTickInspectorPreviewTest::RunTest(const FString& Parameters)
{
    if (!FApp::CanEverRender()) { AddInfo(TEXT("NullRHI: rendered screenshot requires a separate rendering-enabled run.")); return true; }
    TSharedPtr<SDockTab> Tab = FGlobalTabmanager::Get()->TryInvokeTab(FName("TickInspector"));
    ADD_LATENT_AUTOMATION_COMMAND(FWaitLatentCommand(3.0f));
    ADD_LATENT_AUTOMATION_COMMAND(FCaptureTickInspector(this, Tab));
    return true;
}
#endif
