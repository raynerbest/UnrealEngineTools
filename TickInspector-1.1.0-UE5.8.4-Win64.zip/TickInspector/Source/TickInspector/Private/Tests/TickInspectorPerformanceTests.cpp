#if WITH_DEV_AUTOMATION_TESTS
#include "Misc/AutomationTest.h"
#include "Tests/AutomationEditorCommon.h"
#include "Services/TickPerformanceCapture.h"
#include "Editor.h"
#include "Engine/World.h"
#include "GameFramework/Actor.h"
#include "Components/SceneComponent.h"
#include "HAL/IConsoleManager.h"
#include "Framework/Application/SlateApplication.h"
#include "Widgets/SWindow.h"
#include "Misc/App.h"
#include "Misc/Paths.h"
#include "Misc/FileHelper.h"
#include "HAL/FileManager.h"
#include "ImageUtils.h"
#include "EngineUtils.h"
#include "UObject/UObjectArray.h"
#include "Modules/ModuleManager.h"
#include "TraceServices/ITraceServicesModule.h"
#include "TraceServices/AnalysisService.h"
#include "TraceServices/Model/AnalysisSession.h"
#include "TraceServices/Model/TimingProfiler.h"

namespace
{
void DiagnoseComponentScopes(FAutomationTestBase* Test, const FString& TracePath)
{
    auto& Module = FModuleManager::LoadModuleChecked<ITraceServicesModule>(TEXT("TraceServices"));
    auto Session = Module.GetAnalysisService()->Analyze(*TracePath);
    if (!Session) { return; }
    TraceServices::FAnalysisSessionReadScope Lock(*Session);
    const auto* Provider = TraceServices::ReadTimingProfilerProvider(*Session);
    if (!Provider) { return; }
    const auto& Reader = Provider->GetTimerReader();
    int32 Printed = 0;
    Provider->EnumerateTimelines([&](const TraceServices::ITimingProfilerTimeline& Timeline)
    {
        TArray<FString> Stack;
        Timeline.EnumerateEvents(0.0, Session->GetDurationSeconds(), [&](bool bStart, double, const TraceServices::FTimingProfilerEvent& Event)
        {
            if (bStart)
            {
                const auto* Timer = Reader.GetTimer(Event.TimerIndex);
                FString Name = Timer && Timer->Name ? Timer->Name : TEXT("");
                if (Name.Contains(TEXT("PerformanceComponent")) && Printed++ < 4)
                { Test->AddInfo(TEXT("Component timing scope: ") + Name + TEXT("; ancestors: ") + FString::Join(Stack, TEXT(" > "))); }
                Stack.Add(MoveTemp(Name));
            }
            else if (!Stack.IsEmpty()) { Stack.Pop(EAllowShrinking::No); }
            return TraceServices::EEventEnumerate::Continue;
        });
    });
}
struct FPerformanceTestState
{
    TSharedPtr<TickInspector::FPerformanceCapture> Capture;
    TWeakObjectPtr<AActor> Actor;
    TWeakObjectPtr<AActor> OtherActor;
    TSharedPtr<SWindow> ResultsWindow;
    double FinishedAt = 0;
    double RuntimeAt = 0;
    FDelegateHandle RestoreHandle;
    double Started = 0;
    int32 OldBatching = 0;
    bool bManual = false, bRequestedStop = false;
};
class FWaitForPerformance : public IAutomationLatentCommand
{
public:
    FWaitForPerformance(FAutomationTestBase* InTest, TSharedPtr<FPerformanceTestState> InState) : Test(InTest), State(InState) {}
    bool Update() override
    {
        const double Elapsed = FPlatformTime::Seconds() - State->Started;
        if (GEditor->PlayWorld && !State->RuntimeAt)
        {
            State->RuntimeAt = FPlatformTime::Seconds();
            int32 FixtureComponents = 0;
            for (TActorIterator<AActor> It(GEditor->PlayWorld); It; ++It)
            {
                if (It->GetActorNameOrLabel() != TEXT("TickPerformanceFixture") && It->GetActorNameOrLabel() != TEXT("OtherPerformanceFixture")) { continue; }
                USceneComponent* Component = It->GetRootComponent();
                if (Component)
                {
                    ++FixtureComponents;
                    Component->PrimaryComponentTick.bCanEverTick = true;
                    Component->RegisterAllComponentTickFunctions(true);
                    Component->SetComponentTickEnabled(true);
                    Test->TestTrue(TEXT("Runtime fixture component tick registered"), Component->PrimaryComponentTick.IsTickFunctionRegistered());
                    Test->TestTrue(TEXT("Runtime fixture component tick enabled"), Component->IsComponentTickEnabled());
                }
            }
            Test->TestEqual(TEXT("Both runtime component fixtures exist"), FixtureComponents, 2);
        }
        if (State->bManual && GEditor->PlayWorld && !State->bRequestedStop && State->RuntimeAt && FPlatformTime::Seconds() - State->RuntimeAt > 1)
        { GEditor->RequestEndPlayMap(); State->bRequestedStop = true; }
        if (State->Capture->IsBusy() && Elapsed < 90) { return false; }
        if (State->ResultsWindow)
        {
            if (!State->FinishedAt) { State->FinishedAt = FPlatformTime::Seconds(); }
            if (FPlatformTime::Seconds() - State->FinishedAt < 1) { return false; }
            TArray<FColor> Pixels;
            FIntVector Size;
            const bool bScreenshot = FSlateApplication::Get().TakeScreenshot(State->ResultsWindow.ToSharedRef(), Pixels, Size);
            Test->TestTrue(TEXT("Performance graph rendered"), bScreenshot);
            if (bScreenshot)
            {
                const FString Directory = FPaths::ProjectSavedDir() / TEXT("TickInspectorTests");
                IFileManager::Get().MakeDirectory(*Directory, true);
                TArray64<uint8> Png;
                FImageUtils::PNGCompressImageArray(Size.X, Size.Y, TArrayView64<const FColor>(Pixels.GetData(), Pixels.Num()), Png);
                FFileHelper::SaveArrayToFile(Png, *(Directory / (State->bManual ? TEXT("PerformanceManual.png") : TEXT("PerformanceAutomatic.png"))));
            }
            State->ResultsWindow->RequestDestroyWindow(); State->ResultsWindow.Reset();
        }
        Test->TestFalse(TEXT("Capture and analysis finished"), State->Capture->IsBusy());
        Test->TestNull(TEXT("PIE closes after capture"), GEditor->PlayWorld);
        if (State->bManual) { Test->TestTrue(TEXT("Editor Stop was requested before the capture deadline"), State->bRequestedStop); }
        const auto& Report = State->Capture->GetReport();
        Test->TestTrue(*Report.Error, Report.Error.IsEmpty());
        Test->TestTrue(TEXT("Measured PIE frames"), Report.Frames > 0);
        Test->TestTrue(TEXT("Recorded real tick CPU time"), Report.TotalMs > 0);
        const auto* ActorCost = Report.Actors.FindByPredicate([](const auto& Row) { return Row.Label.Contains(TEXT("TickPerformanceFixture")); });
        Test->TestNotNull(TEXT("Fixture attributed to actor instance"), ActorCost);
        if (ActorCost) { Test->TestTrue(TEXT("Fixture has tick samples"), ActorCost->Calls > 0 && ActorCost->TotalMs > 0); }
        const auto* OtherCost = Report.Actors.FindByPredicate([](const auto& Row) { return Row.Label.Contains(TEXT("OtherPerformanceFixture")); });
        Test->TestNotNull(TEXT("Second actor attributed separately"), OtherCost);
        if (ActorCost && OtherCost)
        {
            if (ActorCost->Calls <= Report.Frames || OtherCost->Calls <= Report.Frames) { DiagnoseComponentScopes(Test, Report.TracePath); }
            Test->TestTrue(TEXT("Same-named components retain separate ownership"), ActorCost->Path != OtherCost->Path && OtherCost->Calls > Report.Frames && ActorCost->Calls > Report.Frames);
            Test->AddInfo(FString::Printf(TEXT("Measured %llu frames: actor A %.6f ms (%llu calls), actor B %.6f ms (%llu calls)."), Report.Frames, ActorCost->TotalMs, ActorCost->Calls, OtherCost->TotalMs, OtherCost->Calls));
        }
        Test->TestEqual(TEXT("Batching setting restored"), IConsoleManager::Get().FindConsoleVariable(TEXT("tick.AllowBatchedTicks"))->GetInt(), State->OldBatching);
        if (State->Actor.IsValid()) { State->Actor->GetWorld()->DestroyActor(State->Actor.Get()); }
        if (State->OtherActor.IsValid()) { State->OtherActor->GetWorld()->DestroyActor(State->OtherActor.Get()); }
        FEditorDelegates::EndPIE.Remove(State->RestoreHandle);
        State->Capture.Reset();
        return true;
    }
private:
    FAutomationTestBase* Test;
    TSharedPtr<FPerformanceTestState> State;
};
bool RunCaptureTest(FAutomationTestBase* Test, bool bManual)
{
    if (GEditor->IsPlaySessionInProgress()) { Test->AddError(TEXT("Stop PIE before this test.")); return false; }
    auto State = MakeShared<FPerformanceTestState>();
    State->bManual = bManual;
    UWorld* World = FAutomationEditorCommonUtils::CreateNewMap();
    AActor* Actor = World->SpawnActor<AActor>();
    Actor->SetActorLabel(TEXT("TickPerformanceFixture"));
    Actor->PrimaryActorTick.bCanEverTick = true;
    Actor->PrimaryActorTick.bStartWithTickEnabled = true;
    Actor->PrimaryActorTick.TickInterval = 0;
    USceneComponent* Component = NewObject<USceneComponent>(Actor, TEXT("PerformanceComponent"));
    Component->PrimaryComponentTick.bCanEverTick = true;
    Component->PrimaryComponentTick.bStartWithTickEnabled = true;
    Actor->AddInstanceComponent(Component);
    Actor->SetRootComponent(Component);
    Component->SetAutoActivate(true);
    Component->RegisterComponent();
    AActor* Other = World->SpawnActor<AActor>();
    Other->SetActorLabel(TEXT("OtherPerformanceFixture"));
    Other->PrimaryActorTick.bCanEverTick = true;
    Other->PrimaryActorTick.bStartWithTickEnabled = true;
    USceneComponent* OtherComponent = NewObject<USceneComponent>(Other, TEXT("PerformanceComponent"));
    OtherComponent->PrimaryComponentTick.bCanEverTick = true;
    OtherComponent->PrimaryComponentTick.bStartWithTickEnabled = true;
    Other->AddInstanceComponent(OtherComponent);
    Other->SetRootComponent(OtherComponent);
    OtherComponent->SetAutoActivate(true);
    OtherComponent->RegisterComponent();
    State->OtherActor = Other;
    State->Actor = Actor;
    State->OldBatching = IConsoleManager::Get().FindConsoleVariable(TEXT("tick.AllowBatchedTicks"))->GetInt();
    State->Capture = MakeShared<TickInspector::FPerformanceCapture>();
    State->RestoreHandle = FEditorDelegates::EndPIE.AddLambda([Test](bool)
    {
        if (!GEditor->PlayWorld) { return; }
        for (TActorIterator<AActor> It(GEditor->PlayWorld); It; ++It)
        {
            const TStatId Id = GUObjectArray.ObjectToObjectItem(*It)->StatID;
            Test->TestTrue(TEXT("Temporary object stat identity restored before PIE cleanup"), Id.IsNone() || !FString(Id.GetStatDescriptionWIDE()).StartsWith(TEXT("TickInspector.TickObject/")));
        }
    });
    if (FApp::CanEverRender())
    {
        TWeakPtr<FPerformanceTestState> WeakState = State;
        State->Capture->OnResults = [WeakState](const TickInspector::FPerformanceReport& Report)
        { if (auto Pinned = WeakState.Pin()) { Pinned->ResultsWindow = TickInspector::ShowPerformanceResults(Report); } };
    }
    Test->TestFalse(TEXT("Invalid duration rejected"), State->Capture->Start(-1));
    State->Started = FPlatformTime::Seconds();
    Test->TestTrue(TEXT("PIE capture requested"), State->Capture->Start(bManual ? 10 : 1));
    Test->TestFalse(TEXT("Concurrent capture rejected"), State->Capture->Start(1));
    ADD_LATENT_AUTOMATION_COMMAND(FWaitForPerformance(Test, State));
    return true;
}
}
IMPLEMENT_SIMPLE_AUTOMATION_TEST(FTickPerformanceAutomatic, "TickInspector.Performance.AutomaticDeadline",
    EAutomationTestFlags::EditorContext | EAutomationTestFlags::EngineFilter)
bool FTickPerformanceAutomatic::RunTest(const FString&) { return RunCaptureTest(this, false); }
IMPLEMENT_SIMPLE_AUTOMATION_TEST(FTickPerformanceManual, "TickInspector.Performance.EditorStop",
    EAutomationTestFlags::EditorContext | EAutomationTestFlags::EngineFilter)
bool FTickPerformanceManual::RunTest(const FString&) { return RunCaptureTest(this, true); }
#endif
