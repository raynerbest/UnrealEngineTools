#if WITH_DEV_AUTOMATION_TESTS
#include "Misc/AutomationTest.h"
#include "Framework/Docking/TabManager.h"
#include "Widgets/Docking/SDockTab.h"
#include "ToolMenus.h"

IMPLEMENT_SIMPLE_AUTOMATION_TEST(FTickInspectorFoundationTest, "TickInspector.Foundation.EditorIntegration",
    EAutomationTestFlags::EditorContext | EAutomationTestFlags::EngineFilter)

bool FTickInspectorFoundationTest::RunTest(const FString& Parameters)
{
    UToolMenus::Get()->HandleNextTick();
    UToolMenu* Tools = UToolMenus::Get()->FindMenu("LevelEditor.MainMenu.Tools");
    UToolMenu* Toolbar = UToolMenus::Get()->FindMenu("LevelEditor.LevelEditorToolBar.User");
    TestNotNull(TEXT("Tools menu registered"), Tools);
    TestNotNull(TEXT("Toolbar registered"), Toolbar);
    if (Tools) { TestNotNull(TEXT("Tools section exists"), Tools->FindSection("TickInspector")); }
    if (Toolbar) { TestNotNull(TEXT("Toolbar section exists"), Toolbar->FindSection("TickInspector")); }
    if (Tools && Tools->FindSection("TickInspector"))
    { TestNotNull(TEXT("Tools activation entry exists"), Tools->FindSection("TickInspector")->FindEntry("TickInspector.Open")); }
    if (Toolbar && Toolbar->FindSection("TickInspector"))
    { TestNotNull(TEXT("Toolbar activation button exists"), Toolbar->FindSection("TickInspector")->FindEntry("TickInspector.Open")); }
    TSharedPtr<SDockTab> First = FGlobalTabmanager::Get()->TryInvokeTab(FName("TickInspector"));
    TestTrue(TEXT("Dockable tab opens"), First.IsValid());
    TSharedPtr<SDockTab> Again = FGlobalTabmanager::Get()->TryInvokeTab(FName("TickInspector"));
    TestTrue(TEXT("Repeated activation reuses tab"), First == Again);
    if (First) { First->RequestCloseTab(); }
    return true;
}
#endif
