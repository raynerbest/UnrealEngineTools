#if WITH_DEV_AUTOMATION_TESTS
#include "Misc/AutomationTest.h"
#include "Services/TickOperationService.h"
#include "Services/TickCsvExporter.h"
#include "Editor.h"
#include "Engine/World.h"
#include "Engine/Engine.h"
#include "Engine/Level.h"
#include "GameFramework/Actor.h"
#include "Components/SceneComponent.h"
#include "Misc/Paths.h"
#include "Misc/PackageName.h"
#include "HAL/FileManager.h"
#include "UObject/Package.h"
#include "UObject/SavePackage.h"

using namespace TickInspector;

IMPLEMENT_SIMPLE_AUTOMATION_TEST(FTickInspectorOperationTest, "TickInspector.Operations.PersistentUndoAndSave",
    EAutomationTestFlags::EditorContext | EAutomationTestFlags::EngineFilter)

bool FTickInspectorOperationTest::RunTest(const FString& Parameters)
{
    const FString Directory = FPaths::ConvertRelativePathToFull(FPaths::ProjectSavedDir() / TEXT("TickInspectorTests/"));
    IFileManager::Get().MakeDirectory(*Directory, true);
    FPackageName::RegisterMountPoint(TEXT("/TickInspectorTests/"), Directory);
    UPackage* Package = CreatePackage(TEXT("/TickInspectorTests/Configuration"));
    // This test constructs the entire package, including on repeat runs where
    // an older fixture file exists. No contents are waiting to be loaded.
    Package->MarkAsFullyLoaded();
    UWorld* World = UWorld::CreateWorld(EWorldType::Editor, false, FName("Configuration"), Package);
    World->SetFlags(RF_Public | RF_Standalone);
    GEngine->CreateNewWorldContext(EWorldType::Editor).SetCurrentWorld(World);
    FActorSpawnParameters Spawn;
    Spawn.Name = TEXT("TickInspectorFixture");
    Spawn.ObjectFlags = RF_Transactional;
    AActor* Actor = World->SpawnActor<AActor>(Spawn);
    USceneComponent* Component = NewObject<USceneComponent>(Actor, TEXT("InstanceTickFixture"), RF_Transactional);
    Actor->AddInstanceComponent(Component);
    Actor->SetRootComponent(Component);
    Component->RegisterComponent();
    Actor->PrimaryActorTick.bCanEverTick = true;
    Component->PrimaryComponentTick.bCanEverTick = true;
    Actor->PrimaryActorTick.bStartWithTickEnabled = true;
    Actor->SetActorTickEnabled(true);
    TArray<FRowPtr> Rows{Capture(Actor)};
    FEdit Edit;
    Edit.Enabled = false; Edit.Interval = 0.5f; Edit.Group = TG_PostPhysics;
    FEditResult Result = Apply(Rows, World, Edit, true);
    TestEqual(TEXT("Persistent batch changes actor"), Result.Changed, 1);
    TestFalse(TEXT("Persistent enable action changes startup flag"), bool(Actor->PrimaryActorTick.bStartWithTickEnabled));
    TestEqual(TEXT("Configured interval updated"), Actor->PrimaryActorTick.TickInterval, 0.5f);
    TestEqual(TEXT("Configured group updated"), int32(Actor->PrimaryActorTick.TickGroup), int32(TG_PostPhysics));
    TestTrue(TEXT("Undo transaction succeeds"), GEditor->UndoTransaction());
    TestTrue(TEXT("Undo restores startup flag"), bool(Actor->PrimaryActorTick.bStartWithTickEnabled));
    TestTrue(TEXT("Redo transaction succeeds"), GEditor->RedoTransaction());
    TestFalse(TEXT("Redo restores disabled startup"), bool(Actor->PrimaryActorTick.bStartWithTickEnabled));
    TestEqual(TEXT("Redo restores interval"), Actor->PrimaryActorTick.TickInterval, 0.5f);
    Edit.Enabled.Reset(); Edit.Group.Reset(); Edit.Interval = 0.75f;
    Result = Apply({Capture(Component)}, World, Edit, true);
    TestEqual(TEXT("Instance component configuration is editable"), Result.Changed, 1);
    Edit.Interval = -1;
    Result = Apply(Rows, World, Edit, true);
    TestEqual(TEXT("Negative interval rejected"), Result.Skipped, 1);
    TestEqual(TEXT("Invalid edit preserves value"), Actor->PrimaryActorTick.TickInterval, 0.5f);
    Edit.Interval.Reset(); Edit.Group = TG_NewlySpawned;
    TestEqual(TEXT("Internal group rejected"), Apply(Rows, World, Edit, true).Skipped, 1);
    Component->CreationMethod = EComponentCreationMethod::SimpleConstructionScript;
    TestFalse(TEXT("Construction script components provide rejection reason"), EditEligibility(Component, World, true).IsEmpty());
    Component->CreationMethod = EComponentCreationMethod::Instance;
    FActorSpawnParameters OtherSpawn;
    OtherSpawn.ObjectFlags = RF_Transactional;
    AActor* NoTickActor = World->SpawnActor<AActor>(OtherSpawn);
    FEdit Enable; Enable.Enabled = true;
    TestEqual(TEXT("Capability is never forced"), Apply({Capture(NoTickActor)}, World, Enable, true).Skipped, 1);
    World->DestroyActor(NoTickActor);
    FSavePackageArgs SaveArgs;
    SaveArgs.TopLevelFlags = RF_Public | RF_Standalone;
    SaveArgs.SaveFlags = SAVE_None;
    TestTrue(TEXT("Fixture map saves to disk"), UPackage::SavePackage(Package, World, *(Directory / TEXT("Configuration.umap")), SaveArgs));
    World->DestroyWorld(false);
    GEngine->DestroyWorldContext(World);
    FPackageName::UnRegisterMountPoint(TEXT("/TickInspectorTests/"), Directory);
    return true;
}

IMPLEMENT_SIMPLE_AUTOMATION_TEST(FTickInspectorReloadTest, "TickInspector.Persistence.ReloadFromDisk",
    EAutomationTestFlags::EditorContext | EAutomationTestFlags::EngineFilter)

bool FTickInspectorReloadTest::RunTest(const FString& Parameters)
{
    const FString Directory = FPaths::ConvertRelativePathToFull(FPaths::ProjectSavedDir() / TEXT("TickInspectorTests/"));
    FPackageName::RegisterMountPoint(TEXT("/TickInspectorTests/"), Directory);
    UPackage* Package = LoadPackage(nullptr, TEXT("/TickInspectorTests/Configuration"), LOAD_None);
    if (!TestNotNull(TEXT("Saved fixture loads; run Operations.PersistentUndoAndSave first"), Package))
    { FPackageName::UnRegisterMountPoint(TEXT("/TickInspectorTests/"), Directory); return false; }
    UWorld* World = UWorld::FindWorldInPackage(Package);
    TestNotNull(TEXT("Saved world found"), World);
    AActor* Actor = World ? FindObject<AActor>(World->PersistentLevel, TEXT("TickInspectorFixture")) : nullptr;
    TestNotNull(TEXT("Fixture actor restored"), Actor);
    if (Actor)
    {
        TestFalse(TEXT("Startup flag survives disk load"), bool(Actor->PrimaryActorTick.bStartWithTickEnabled));
        TestEqual(TEXT("Interval survives disk load"), Actor->PrimaryActorTick.TickInterval, 0.5f);
        TestEqual(TEXT("Group survives disk load"), int32(Actor->PrimaryActorTick.TickGroup), int32(TG_PostPhysics));
        USceneComponent* Component = FindObject<USceneComponent>(Actor, TEXT("InstanceTickFixture"));
        TestNotNull(TEXT("Instance component restored"), Component);
        if (Component) { TestEqual(TEXT("Instance component interval survives disk load"), Component->PrimaryComponentTick.TickInterval, 0.75f); }
    }
    FPackageName::UnRegisterMountPoint(TEXT("/TickInspectorTests/"), Directory);
    return true;
}

IMPLEMENT_SIMPLE_AUTOMATION_TEST(FTickInspectorSessionTest, "TickInspector.Operations.PieIsolation",
    EAutomationTestFlags::EditorContext | EAutomationTestFlags::EngineFilter)

bool FTickInspectorSessionTest::RunTest(const FString& Parameters)
{
    UWorld* Pie = UWorld::CreateWorld(EWorldType::PIE, false);
    GEngine->CreateNewWorldContext(EWorldType::PIE).SetCurrentWorld(Pie);
    AActor* Actor = Pie->SpawnActor<AActor>();
    Actor->PrimaryActorTick.bCanEverTick = true;
    Actor->PrimaryActorTick.bStartWithTickEnabled = false;
    FEdit Edit; Edit.Enabled = true; Edit.Interval = 0.2f;
    const FEditResult Result = Apply({Capture(Actor)}, Pie, Edit, false);
    TestEqual(TEXT("Session edit accepted"), Result.Changed, 1);
    TestTrue(TEXT("PIE runtime tick enabled"), Actor->IsActorTickEnabled());
    TestFalse(TEXT("PIE startup configuration unchanged"), bool(Actor->PrimaryActorTick.bStartWithTickEnabled));
    TestEqual(TEXT("PIE interval updated"), Actor->GetActorTickInterval(), 0.2f);
    TestFalse(TEXT("Persistent edit of PIE rejected"), EditEligibility(Actor, Pie, true).IsEmpty());
    Pie->DestroyWorld(false);
    GEngine->DestroyWorldContext(Pie);
    return true;
}

IMPLEMENT_SIMPLE_AUTOMATION_TEST(FTickInspectorCsvTest, "TickInspector.Operations.CsvEscaping",
    EAutomationTestFlags::EditorContext | EAutomationTestFlags::EngineFilter)

bool FTickInspectorCsvTest::RunTest(const FString& Parameters)
{
    TestEqual(TEXT("CSV escapes quotes and commas"), CsvCell(TEXT("Actor, \"quoted\"")), FString(TEXT("\"Actor, \"\"quoted\"\"\"")));
    TestEqual(TEXT("CSV preserves embedded newline"), CsvCell(TEXT("Line\nTwo")), FString(TEXT("\"Line\nTwo\"")));
    TestEqual(TEXT("CSV neutralizes formulas"), CsvCell(TEXT("=1+1")), FString(TEXT("\"'=1+1\"")));
    FRowPtr Row = MakeShared<FRow>(); Row->Name = TEXT("Unicode \u65e5\u672c"); Row->Key = TEXT("fixture");
    const FString Text = Csv({Row}, TEXT("PIE 0 | Server"), TEXT("Selected rows"));
    TestTrue(TEXT("CSV identifies world and scope"), Text.Contains(TEXT("PIE 0 | Server")) && Text.Contains(TEXT("Selected rows")));
    TestTrue(TEXT("CSV preserves Unicode"), Text.Contains(Row->Name));
    return true;
}
#endif
