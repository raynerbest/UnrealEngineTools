#if WITH_DEV_AUTOMATION_TESTS
#include "Misc/AutomationTest.h"
#include "Services/TickDiscoveryService.h"
#include "Engine/World.h"
#include "Engine/Engine.h"
#include "GameFramework/Actor.h"
#include "Components/SceneComponent.h"

IMPLEMENT_SIMPLE_AUTOMATION_TEST(FTickInspectorDiscoveryTest, "TickInspector.Discovery.LifecycleAndSnapshot",
    EAutomationTestFlags::EditorContext | EAutomationTestFlags::EngineFilter)

bool FTickInspectorDiscoveryTest::RunTest(const FString& Parameters)
{
    using namespace TickInspector;
    UWorld* World = UWorld::CreateWorld(EWorldType::Editor, false);
    if (!TestNotNull(TEXT("Test world created"), World)) { return false; }
    GEngine->CreateNewWorldContext(EWorldType::Editor).SetCurrentWorld(World);
    FActorSpawnParameters Spawn;
    Spawn.ObjectFlags = RF_Transactional;
    AActor* Actor = World->SpawnActor<AActor>(Spawn);
    Actor->SetActorLabel(TEXT("TickInspector fixture"));
    Actor->PrimaryActorTick.bCanEverTick = true;
    Actor->PrimaryActorTick.bStartWithTickEnabled = false;
    Actor->SetActorTickEnabled(true);
    Actor->SetActorTickInterval(0.25f);
    UActorComponent* Component = NewObject<USceneComponent>(Actor, NAME_None, RF_Transactional);
    Actor->AddInstanceComponent(Component);
    Component->RegisterComponent();
    FDiscoveryService Discovery;
    Discovery.SetWorld(World);
    Discovery.Update();
    for (int32 Step = 0; Discovery.IsScanning() && Step < 10000; ++Step) { Discovery.Update(); }
    TestFalse(TEXT("Incremental scan completes"), Discovery.IsScanning());
    const FRowPtr* Row = Discovery.GetRows().FindByPredicate([Actor](const FRowPtr& Item) { return Item->Object.Get() == Actor; });
    TestTrue(TEXT("Actor discovered"), Row != nullptr);
    if (Row)
    {
        TestTrue(TEXT("Runtime enabled sampled"), (*Row)->bEnabled);
        TestFalse(TEXT("Startup flag remains distinct"), (*Row)->bStartEnabled);
        TestEqual(TEXT("Interval sampled"), (*Row)->Interval, 0.25f);
    }
    TestTrue(TEXT("Component discovered independently"), Discovery.GetRows().ContainsByPredicate(
        [Component](const FRowPtr& Item) { return Item->Object.Get() == Component && Item->bComponent; }));
    Discovery.Cancel();
    TestFalse(TEXT("Cancellation stops in-progress work"), Discovery.IsScanning());
    World->DestroyActor(Actor);
    Discovery.RequestScan(); Discovery.Update();
    for (int32 Step = 0; Discovery.IsScanning() && Step < 10000; ++Step) { Discovery.Update(); }
    TestFalse(TEXT("Destroyed actor excluded on rescan"), Discovery.GetRows().ContainsByPredicate(
        [Actor](const FRowPtr& Item) { return Item->Object.Get() == Actor; }));
    World->DestroyWorld(false);
    GEngine->DestroyWorldContext(World);
    TestNull(TEXT("World cleanup invalidates active world"), Discovery.GetWorld());
    TestEqual(TEXT("World cleanup clears rows"), Discovery.GetRows().Num(), 0);
    return true;
}
#endif
