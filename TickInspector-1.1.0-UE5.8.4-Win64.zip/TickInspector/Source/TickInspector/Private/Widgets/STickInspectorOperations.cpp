#include "STickInspector.h"
#include "Services/TickDiscoveryService.h"
#include "Services/TickOperationService.h"
#include "Services/TickCsvExporter.h"
#include "DesktopPlatformModule.h"
#include "IDesktopPlatform.h"
#include "Framework/Application/SlateApplication.h"
#include "Engine/World.h"
#include "Misc/Paths.h"
#include "Widgets/Input/SButton.h"
#include "Widgets/Input/SComboBox.h"
#include "Widgets/Input/SNumericEntryBox.h"
#include "Widgets/Layout/SWrapBox.h"
#include "Widgets/Text/STextBlock.h"

using namespace TickInspector;

TSharedRef<SWidget> STickInspector::BuildOperations()
{
    for (ETickingGroup Group : {TG_PrePhysics, TG_DuringPhysics, TG_PostPhysics, TG_PostUpdateWork})
    { GroupChoices.Add(MakeShared<FString>(GroupName(Group))); }
    auto HasSelection = [this] { return List && List->GetNumItemsSelected() > 0 && Discovery->GetWorld(); };
    return SNew(SVerticalBox)
        + SVerticalBox::Slot().AutoHeight()[SNew(STextBlock).AutoWrapText(true).Text_Lambda([this]
            { UWorld* World = Discovery->GetWorld(); return FText::FromString(World && World->WorldType == EWorldType::PIE
                ? TEXT("Operations: PIE SESSION ONLY. Changes are temporary and are not editor Undo transactions.")
                : TEXT("Operations: PERSISTENT EDITOR CONFIGURATION. Enabled changes the startup flag. Save modified levels/actors to retain changes; Ctrl+Z/Ctrl+Y supports Undo/Redo. Stop PIE first.")); })]
        + SVerticalBox::Slot().AutoHeight().Padding(0, 4)[SNew(SWrapBox).UseAllottedSize(true)
            + SWrapBox::Slot().Padding(0, 0, 6, 4)[SNew(SButton).Text(FText::FromString(TEXT("Enable selected"))).IsEnabled_Lambda(HasSelection)
                .OnClicked_Lambda([this] { FEdit Edit; Edit.Enabled = true; return ApplySelected(Edit); })]
            + SWrapBox::Slot().Padding(0, 0, 10, 4)[SNew(SButton).Text(FText::FromString(TEXT("Disable selected"))).IsEnabled_Lambda(HasSelection)
                .OnClicked_Lambda([this] { FEdit Edit; Edit.Enabled = false; return ApplySelected(Edit); })]
            + SWrapBox::Slot().Padding(0, 0, 6, 4)[SNew(SNumericEntryBox<float>).MinValue(0).AllowSpin(true).MinSliderValue(0).MaxSliderValue(10)
                .MinDesiredValueWidth(85).Value_Lambda([this] { return TOptional<float>(EditInterval); })
                .OnValueChanged_Lambda([this](float Value) { EditInterval = Value; })]
            + SWrapBox::Slot().Padding(0, 0, 10, 4)[SNew(SButton).Text(FText::FromString(TEXT("Set interval (s)"))).IsEnabled_Lambda(HasSelection)
                .OnClicked_Lambda([this] { FEdit Edit; Edit.Interval = EditInterval; return ApplySelected(Edit); })]
            + SWrapBox::Slot().Padding(0, 0, 6, 4)[SNew(SComboBox<TSharedPtr<FString>>).OptionsSource(&GroupChoices).InitiallySelectedItem(GroupChoices[0])
                .OnGenerateWidget_Lambda([](TSharedPtr<FString> Value) { return SNew(STextBlock).Text(FText::FromString(*Value)); })
                .OnSelectionChanged_Lambda([this](TSharedPtr<FString> Value, ESelectInfo::Type)
                { for (ETickingGroup Group : {TG_PrePhysics, TG_DuringPhysics, TG_PostPhysics, TG_PostUpdateWork})
                    { if (Value && *Value == GroupName(Group)) { EditGroup = Group; } } })
                [SNew(STextBlock).Text_Lambda([this] { return FText::FromString(GroupName(EditGroup)); })]]
            + SWrapBox::Slot().Padding(0, 0, 10, 4)[SNew(SButton).Text(FText::FromString(TEXT("Set group"))).IsEnabled_Lambda(HasSelection)
                .ToolTipText(FText::FromString(TEXT("Changes the configured start group. Prerequisites may delay actual execution. Does not rewrite dependencies or the end group.")))
                .OnClicked_Lambda([this] { FEdit Edit; Edit.Group = EditGroup; return ApplySelected(Edit); })]
            + SWrapBox::Slot().Padding(0, 0, 6, 4)[SNew(SButton).Text(FText::FromString(TEXT("Export selected CSV"))).IsEnabled_Lambda(HasSelection)
                .OnClicked_Lambda([this] { return SaveCsv(true); })]
            + SWrapBox::Slot().Padding(0, 0, 0, 4)[SNew(SButton).Text(FText::FromString(TEXT("Export filtered CSV")))
                .IsEnabled_Lambda([this] { return !Results.IsEmpty(); }).OnClicked_Lambda([this] { return SaveCsv(false); })]];
}

FReply STickInspector::ApplySelected(const FEdit& Edit)
{
    UWorld* World = Discovery->GetWorld();
    if (!World) { Message = TEXT("Choose a valid world first."); return FReply::Handled(); }
    Message = Apply(List->GetSelectedItems(), World, Edit, World->WorldType == EWorldType::Editor).Summary();
    Discovery->RequestScan();
    return FReply::Handled();
}

FReply STickInspector::SaveCsv(bool bSelected)
{
    IDesktopPlatform* Desktop = FDesktopPlatformModule::Get();
    if (!Desktop) { Message = TEXT("A native save dialog is unavailable on this platform."); return FReply::Handled(); }
    TArray<FString> Files;
    const bool bChosen = Desktop->SaveFileDialog(FSlateApplication::Get().FindBestParentWindowHandleForDialogs(AsShared()),
        TEXT("Export Tick Inspector snapshot"), FPaths::ProjectSavedDir(),
        TEXT("TickInspector-") + FDateTime::UtcNow().ToString(TEXT("%Y%m%d-%H%M%S")) + TEXT(".csv"),
        TEXT("CSV files (*.csv)|*.csv"), 0, Files);
    if (bChosen && !Files.IsEmpty())
    {
        const FString Filename = FPaths::ChangeExtension(Files[0], TEXT("csv"));
        auto Choice = WorldCombo->GetSelectedItem();
        Message = ExportCsv(Filename, bSelected ? List->GetSelectedItems() : Results,
            Choice ? Choice->Label : TEXT("Expired world snapshot"), bSelected ? TEXT("Selected rows") : TEXT("Filtered rows"))
            ? TEXT("CSV exported: ") + Filename : TEXT("CSV export failed. Check the destination path and permissions.");
    }
    return FReply::Handled();
}
