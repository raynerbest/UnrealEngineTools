#pragma once
#include "Widgets/SCompoundWidget.h"
#include "Model/TickInspectorTypes.h"
#include "Widgets/Views/SListView.h"

template<typename OptionType> class SComboBox;
namespace TickInspector { class FDiscoveryService; }
namespace TickInspector { struct FEdit; }
namespace TickInspector { class FViewportVisualization; }
namespace TickInspector { class FPerformanceCapture; }

class STickInspector : public SCompoundWidget
{
public:
    SLATE_BEGIN_ARGS(STickInspector) {} SLATE_END_ARGS()
    void Construct(const FArguments& Args);
    virtual ~STickInspector() override;
    virtual void Tick(const FGeometry& Geometry, double CurrentTime, float DeltaTime) override;
private:
    void SyncWorlds();
    void RebuildResults();
    FText StatusText() const;
    FText DetailsText() const;
    TSharedRef<ITableRow> MakeRow(TickInspector::FRowPtr Row, const TSharedRef<STableViewBase>& Owner);
    void SelectionChanged(TickInspector::FRowPtr Row, ESelectInfo::Type Type);
    TSharedRef<SWidget> BuildOperations();
    TSharedRef<SWidget> BuildPerformance();
    FReply ApplySelected(const TickInspector::FEdit& Edit);
    FReply SaveCsv(bool bSelected);
    TSharedPtr<TickInspector::FDiscoveryService> Discovery;
    TArray<TSharedPtr<TickInspector::FWorldChoice>> WorldChoices;
    TSharedPtr<SComboBox<TSharedPtr<TickInspector::FWorldChoice>>> WorldCombo;
    TArray<TSharedPtr<FString>> Filters;
    TArray<TickInspector::FRowPtr> Results;
    TSharedPtr<SListView<TickInspector::FRowPtr>> List;
    FString Search, Filter = TEXT("All primary ticks"), WorldsSignature, Message;
    FName SortColumn = TEXT("Actor");
    EColumnSortMode::Type SortMode = EColumnSortMode::Ascending;
    uint64 DisplayRevision = MAX_uint64;
    double NextWorldRefresh = 0;
    bool bFocusOnClick = false, bSyncing = false;
    float EditInterval = 0;
    ETickingGroup EditGroup = TG_PrePhysics;
    TArray<TSharedPtr<FString>> GroupChoices;
    TSharedPtr<TickInspector::FViewportVisualization> Visualization;
    bool bHighlight = true;
    double NextVisualizationUpdate = 0;
    TSharedPtr<TickInspector::FPerformanceCapture> Performance;
    double CaptureSeconds = 10;
};
