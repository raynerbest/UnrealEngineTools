#include "STickInspector.h"
#include "Services/TickPerformanceCapture.h"
#include "Framework/Application/SlateApplication.h"
#include "Widgets/SWindow.h"
#include "Widgets/Input/SButton.h"
#include "Widgets/Input/SSpinBox.h"
#include "Widgets/Layout/SBorder.h"
#include "Widgets/Layout/SBox.h"
#include "Widgets/Layout/SScrollBox.h"
#include "Widgets/Notifications/SProgressBar.h"
#include "Widgets/Text/STextBlock.h"

namespace TickInspector
{
TSharedRef<SWindow> ShowPerformanceResults(const FPerformanceReport& Report)
{
    TSharedRef<SVerticalBox> Rows = SNew(SVerticalBox);
    Rows->AddSlot().AutoHeight().Padding(4)[SNew(STextBlock).AutoWrapText(true).Text(FText::FromString(
        FString::Printf(TEXT("%llu PIE frames | %.3f ms total measured tick CPU | %.4f ms/frame | %llu unattributed scopes"),
            Report.Frames, Report.TotalMs, Report.Frames ? Report.TotalMs / Report.Frames : 0.0, Report.UnattributedScopes)))];
    Rows->AddSlot().AutoHeight().Padding(4)[SNew(STextBlock).AutoWrapText(true).Text(FText::FromString(
        TEXT("Actor primary tick + owned primary component ticks. Bars: share of measured tick CPU. Inclusive synchronous work; parallel times can overlap. This is not total actor cost, GPU cost or predicted FPS savings. PIE and profiling add overhead. Tick batching is temporarily disabled for per-instance attribution and restored afterward. No sample means no attributable execution, not a measured zero.")))];
    if (!Report.Error.IsEmpty())
    { Rows->AddSlot().AutoHeight().Padding(4)[SNew(STextBlock).AutoWrapText(true).ColorAndOpacity(FLinearColor::Yellow).Text(FText::FromString(Report.Error))]; }
    Rows->AddSlot().AutoHeight().Padding(4)[SNew(STextBlock).AutoWrapText(true).Text(FText::FromString(TEXT("Actor | Total CPU ms | CPU ms/PIE frame | Max single tick ms | Tick calls | Share")))];
    for (const auto& Actor : Report.Actors)
    {
        const float Share = Report.TotalMs > 0 ? Actor.TotalMs / Report.TotalMs : 0;
        const FString Values = Actor.Calls ? FString::Printf(TEXT("%s | %.3f | %.4f | %.4f | %llu | %.2f%%"),
            *Actor.Label, Actor.TotalMs, Report.Frames ? Actor.TotalMs / Report.Frames : 0.0,
            Actor.MaxTickMs, Actor.Calls, Share * 100) : Actor.Label + TEXT(" | No attributable tick samples");
        Rows->AddSlot().AutoHeight().Padding(4, 5)[SNew(SVerticalBox)
            + SVerticalBox::Slot().AutoHeight()[SNew(STextBlock).AutoWrapText(true).Text(FText::FromString(Values)).ToolTipText(FText::FromString(Actor.Path))]
            + SVerticalBox::Slot().AutoHeight().Padding(0, 3)[SNew(SBox).HeightOverride(12)[SNew(SProgressBar).Percent(Share)
                .FillColorAndOpacity(FLinearColor(0.05f, 0.65f, 0.85f))]]];
    }
    Rows->AddSlot().AutoHeight().Padding(4)[SNew(STextBlock).AutoWrapText(true).Text(FText::FromString(TEXT("Trace retained for Unreal Insights: ") + Report.TracePath))];
    auto Window = SNew(SWindow).Title(FText::FromString(TEXT("Tick Inspector - PIE performance results")))
        .ClientSize(FVector2D(1000, 680))[SNew(SBorder).Padding(12)[SNew(SScrollBox) + SScrollBox::Slot()[Rows]]];
    FSlateApplication::Get().AddWindow(Window);
    return Window;
}
}

TSharedRef<SWidget> STickInspector::BuildPerformance()
{
    Performance = MakeShared<TickInspector::FPerformanceCapture>();
    Performance->OnResults = [](const TickInspector::FPerformanceReport& Report) { TickInspector::ShowPerformanceResults(Report); };
    return SNew(SBorder).Padding(6)[SNew(SVerticalBox)
        + SVerticalBox::Slot().AutoHeight()[SNew(SHorizontalBox)
            + SHorizontalBox::Slot().AutoWidth().VAlign(VAlign_Center).Padding(0, 0, 8, 0)[SNew(STextBlock).Text(FText::FromString(TEXT("PIE performance capture (seconds)")))]
            + SHorizontalBox::Slot().AutoWidth().Padding(0, 0, 8, 0)[SNew(SBox).WidthOverride(90)[SNew(SSpinBox<double>)
                .MinValue(0.1).MaxValue(600).Value_Lambda([this] { return CaptureSeconds; })
                .IsEnabled_Lambda([this] { return !Performance->IsBusy(); })
                .OnValueChanged_Lambda([this](double Value) { CaptureSeconds = Value; })]]
            + SHorizontalBox::Slot().AutoWidth().Padding(0, 0, 8, 0)[SNew(SButton).Text(FText::FromString(TEXT("Run PIE & measure")))
                .IsEnabled_Lambda([this] { return !Performance->IsBusy(); })
                .OnClicked_Lambda([this] { Performance->Start(CaptureSeconds); return FReply::Handled(); })]
            + SHorizontalBox::Slot().AutoWidth()[SNew(SButton).Text(FText::FromString(TEXT("Stop measurement")))
                .IsEnabled_Lambda([this] { return Performance->CanStop(); })
                .OnClicked_Lambda([this] { Performance->Stop(); return FReply::Handled(); })]
            + SHorizontalBox::Slot().AutoWidth().Padding(8, 0)[SNew(SButton).Text(FText::FromString(TEXT("Show last results")))
                .IsEnabled_Lambda([this] { return !Performance->IsBusy() && (!Performance->GetReport().Actors.IsEmpty() || !Performance->GetReport().Error.IsEmpty()); })
                .OnClicked_Lambda([this] { TickInspector::ShowPerformanceResults(Performance->GetReport()); return FReply::Handled(); })]]
        + SVerticalBox::Slot().AutoHeight().Padding(0, 4)[SNew(STextBlock).AutoWrapText(true)
            .Text_Lambda([this] { return FText::FromString(Performance->Status()); })]];
}
