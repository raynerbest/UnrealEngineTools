#include "STickInspector.h"
#include "Services/TickDiscoveryService.h"
#include "Services/TickNavigationService.h"
#include "Services/TickViewportVisualization.h"
#include "Services/TickDiagnostics.h"
#include "Services/TickPerformanceCapture.h"
#include "Engine/World.h"
#include "Widgets/Input/SButton.h"
#include "Widgets/Input/SCheckBox.h"
#include "Widgets/Input/SComboBox.h"
#include "Widgets/Input/SSearchBox.h"
#include "Widgets/Layout/SBorder.h"
#include "Widgets/Layout/SScrollBox.h"
#include "Widgets/Layout/SBox.h"
#include "Widgets/Text/STextBlock.h"
#include "Widgets/Views/SHeaderRow.h"

using namespace TickInspector;

namespace
{
FString Cell(const FRow& Row, FName Column)
{
    if (Column == "Actor") { return Row.ActorName; }
    if (Column == "Name") { return Row.Name; }
    if (Column == "Kind") { return Row.bComponent ? TEXT("Component") : TEXT("Actor"); }
    if (Column == "Class") { return Row.ClassName; }
    if (Column == "CanTick") { return Row.bCanTick ? TEXT("Yes") : TEXT("No"); }
    if (Column == "Enabled") { return Row.bEnabled ? TEXT("Yes") : TEXT("No"); }
    if (Column == "Start") { return Row.bStartEnabled ? TEXT("Yes") : TEXT("No"); }
    if (Column == "Registered") { return Row.bRegistered ? TEXT("Yes") : TEXT("No"); }
    if (Column == "ComponentRegistered") { return Row.bComponent ? (Row.bComponentRegistered ? TEXT("Yes") : TEXT("No")) : TEXT("N/A"); }
    if (Column == "Interval") { return FString::Printf(TEXT("%.6g"), Row.Interval); }
    if (Column == "Group") { return GroupName(Row.Group); }
    if (Column == "EndGroup") { return GroupName(Row.EndGroup); }
    if (Column == "Prerequisites") { return FString::FromInt(Row.Prerequisites); }
    if (Column == "Diagnostics") { return Diagnostics(Row); }
    return Row.Level;
}

class STickInspectorRow : public SMultiColumnTableRow<FRowPtr>
{
public:
    SLATE_BEGIN_ARGS(STickInspectorRow) {} SLATE_ARGUMENT(FRowPtr, Row) SLATE_END_ARGS()
    void Construct(const FArguments& Args, const TSharedRef<STableViewBase>& Owner)
    {
        Row = Args._Row;
        SMultiColumnTableRow::Construct(FSuperRowType::FArguments().Padding(3), Owner);
        SetToolTipText(FText::FromString(Row->Key + TEXT("\nCaptured UTC: ") + Row->Captured.ToIso8601()));
    }
    virtual TSharedRef<SWidget> GenerateWidgetForColumn(const FName& Column) override
    { return SNew(STextBlock).Text(FText::FromString(Cell(*Row, Column))); }
private:
    FRowPtr Row;
};
}

STickInspector::~STickInspector() = default;

void STickInspector::Construct(const FArguments& Args)
{
    Discovery = MakeShared<FDiscoveryService>();
    Visualization = MakeShared<FViewportVisualization>();
    for (const TCHAR* Name : {TEXT("All primary ticks"), TEXT("Enabled"), TEXT("Disabled"), TEXT("Can tick"),
        TEXT("Cannot tick"), TEXT("Unregistered"), TEXT("Actors"), TEXT("Components")}) { Filters.Add(MakeShared<FString>(Name)); }
    TSharedRef<SHeaderRow> Header = SNew(SHeaderRow);
    auto Column = [this, &Header](const char* Id, const TCHAR* Label, float Width)
    {
        Header->AddColumn(SHeaderRow::Column(FName(Id)).DefaultLabel(FText::FromString(Label)).FixedWidth(Width)
            .SortMode_Lambda([this, Name = FName(Id)] { return SortColumn == Name ? SortMode : EColumnSortMode::None; })
            .OnSort_Lambda([this](EColumnSortPriority::Type, const FName& Name, EColumnSortMode::Type Mode)
            { SortColumn = Name; SortMode = Mode; RebuildResults(); }));
    };
    Column("Actor", TEXT("Actor"), 170); Column("Name", TEXT("Tick owner"), 185);
    Column("Kind", TEXT("Kind"), 90); Column("Class", TEXT("Class"), 170);
    Column("CanTick", TEXT("Can tick"), 80); Column("Enabled", TEXT("Enabled now"), 100);
    Column("Start", TEXT("Start enabled"), 105); Column("Registered", TEXT("Tick registered"), 110);
    Column("ComponentRegistered", TEXT("Comp. registered"), 120); Column("Interval", TEXT("Interval (s)"), 95);
    Column("Group", TEXT("Group (configured)"), 155); Column("EndGroup", TEXT("End group"), 140);
    Column("Prerequisites", TEXT("Prerequisites"), 100); Column("Level", TEXT("Level"), 260);
    Column("Diagnostics", TEXT("Configuration observations (not profiling)"), 500);

    ChildSlot[SNew(SBorder).Padding(8)[SNew(SVerticalBox)
        + SVerticalBox::Slot().AutoHeight().Padding(0, 0, 0, 6)[SNew(SHorizontalBox)
            + SHorizontalBox::Slot().AutoWidth().Padding(0, 0, 8, 0)[SAssignNew(WorldCombo, SComboBox<TSharedPtr<FWorldChoice>>)
                .OptionsSource(&WorldChoices)
                .OnGenerateWidget_Lambda([](TSharedPtr<FWorldChoice> Choice) { return SNew(STextBlock).Text(FText::FromString(Choice->Label)); })
                .OnSelectionChanged_Lambda([this](TSharedPtr<FWorldChoice> Choice, ESelectInfo::Type)
                { if (!bSyncing) { Discovery->SetWorld(Choice ? Choice->World.Get() : nullptr); Message.Empty(); } })
                [SNew(STextBlock).Text_Lambda([this] { auto Choice = WorldCombo->GetSelectedItem();
                    return FText::FromString(Choice ? Choice->Label : TEXT("No editor or PIE world")); })]]
            + SHorizontalBox::Slot().AutoWidth().Padding(0, 0, 6, 0)[SNew(SButton).Text(FText::FromString(TEXT("Scan now")))
                .OnClicked_Lambda([this] { Discovery->RequestScan(); return FReply::Handled(); })]
            + SHorizontalBox::Slot().AutoWidth().Padding(0, 0, 6, 0)[SNew(SButton).Text(FText::FromString(TEXT("Cancel scan")))
                .OnClicked_Lambda([this] { Discovery->Cancel(); Message = TEXT("Scan cancelled; the last completed snapshot is retained."); return FReply::Handled(); })]
            + SHorizontalBox::Slot().AutoWidth()[SNew(SCheckBox)
                .OnCheckStateChanged_Lambda([this](ECheckBoxState State) { bFocusOnClick = State == ECheckBoxState::Checked; })
                [SNew(STextBlock).Text(FText::FromString(TEXT("Focus on click")))]]
            + SHorizontalBox::Slot().AutoWidth().Padding(8, 0)[SNew(SCheckBox).IsChecked(ECheckBoxState::Checked)
                .OnCheckStateChanged_Lambda([this](ECheckBoxState State) { bHighlight = State == ECheckBoxState::Checked; })
                .ToolTipText(FText::FromString(TEXT("Draw selected actor bounds without altering scene objects. Limited to 128 actors. Requires the On Screen Debug show flag; bounds are not occlusion-aware.")))
                [SNew(STextBlock).Text(FText::FromString(TEXT("Highlight bounds")))]]]
        + SVerticalBox::Slot().AutoHeight().Padding(0, 0, 0, 6)[SNew(SHorizontalBox)
            + SHorizontalBox::Slot().FillWidth(1).Padding(0, 0, 8, 0)[SNew(SSearchBox)
                .HintText(FText::FromString(TEXT("Search actor, component, class, group, level or path")))
                .OnTextChanged_Lambda([this](const FText& Text) { Search = Text.ToString().ToLower(); RebuildResults(); })]
            + SHorizontalBox::Slot().AutoWidth()[SNew(SComboBox<TSharedPtr<FString>>).OptionsSource(&Filters).InitiallySelectedItem(Filters[0])
                .OnGenerateWidget_Lambda([](TSharedPtr<FString> Value) { return SNew(STextBlock).Text(FText::FromString(*Value)); })
                .OnSelectionChanged_Lambda([this](TSharedPtr<FString> Value, ESelectInfo::Type)
                { if (Value) { Filter = *Value; RebuildResults(); } })
                [SNew(STextBlock).Text_Lambda([this] { return FText::FromString(Filter); })]]]
        + SVerticalBox::Slot().AutoHeight().Padding(0, 0, 0, 6)[SNew(STextBlock).AutoWrapText(true).Text_Lambda([this]
            { UWorld* World = Discovery->GetWorld(); return FText::FromString(World && World->WorldType == EWorldType::PIE
                ? TEXT("PIE: live state is a snapshot. Session changes do not persist. Navigation uses editor counterparts when available.")
                : TEXT("Editor: enabled/registered does not mean executing. Primary ticks of loaded actors/components only; unloaded World Partition tick state is unknown.")); })]
        + SVerticalBox::Slot().AutoHeight().Padding(0, 0, 0, 6)[BuildPerformance()]
        + SVerticalBox::Slot().AutoHeight().Padding(0, 0, 0, 6)[BuildOperations()]
        + SVerticalBox::Slot().FillHeight(1)[SNew(SScrollBox).Orientation(Orient_Horizontal)
            + SScrollBox::Slot()[SNew(SBox).WidthOverride(2485)[SAssignNew(List, SListView<FRowPtr>)
                .ListItemsSource(&Results).SelectionMode(ESelectionMode::Multi).HeaderRow(Header)
                .OnGenerateRow(this, &STickInspector::MakeRow).OnSelectionChanged(this, &STickInspector::SelectionChanged)
                .OnMouseButtonDoubleClick_Lambda([](FRowPtr Row) { Navigate({Row}, true); })]]]
        + SVerticalBox::Slot().AutoHeight().Padding(0, 6)[SNew(STextBlock).AutoWrapText(true).Text(this, &STickInspector::DetailsText)]
        + SVerticalBox::Slot().AutoHeight()[SNew(STextBlock).AutoWrapText(true).Text(this, &STickInspector::StatusText)]
    ]];
    SyncWorlds();
}

void STickInspector::SyncWorlds()
{
    TArray<TSharedPtr<FWorldChoice>> Choices = FDiscoveryService::Worlds();
    FString Signature;
    for (const auto& Choice : Choices) { Signature += Choice->Label + FString::FromInt(Choice->World->GetUniqueID()); }
    if (Signature == WorldsSignature) { return; }
    WorldsSignature = Signature;
    UWorld* Previous = Discovery->GetWorld();
    bSyncing = true;
    WorldChoices = MoveTemp(Choices);
    WorldCombo->RefreshOptions();
    TSharedPtr<FWorldChoice> Selected;
    for (const auto& Choice : WorldChoices) { if (Choice->World.Get() == Previous) { Selected = Choice; break; } }
    if (!Selected && !WorldChoices.IsEmpty()) { Selected = WorldChoices[0]; }
    WorldCombo->SetSelectedItem(Selected);
    if (Previous != (Selected ? Selected->World.Get() : nullptr)) { Discovery->SetWorld(Selected ? Selected->World.Get() : nullptr); }
    bSyncing = false;
}

void STickInspector::Tick(const FGeometry& Geometry, double CurrentTime, float DeltaTime)
{
    SCompoundWidget::Tick(Geometry, CurrentTime, DeltaTime);
    if (CurrentTime >= NextWorldRefresh) { SyncWorlds(); NextWorldRefresh = CurrentTime + 0.5; }
    if (!Performance || !Performance->IsBusy()) { Discovery->Update(); }
    if (Discovery->GetRevision() != DisplayRevision) { RebuildResults(); }
    if (CurrentTime >= NextVisualizationUpdate)
    {
        Visualization->Update(Discovery->GetWorld(), List->GetSelectedItems(), bHighlight && (!Performance || !Performance->IsBusy()));
        NextVisualizationUpdate = CurrentTime + 0.1;
    }
}

void STickInspector::RebuildResults()
{
    if (!Discovery || !List) { return; }
    DisplayRevision = Discovery->GetRevision();
    TSet<TWeakObjectPtr<UObject>> Selected;
    for (const auto& Row : List->GetSelectedItems()) { Selected.Add(Row->Object); }
    Results.Reset();
    for (const auto& Row : Discovery->GetRows())
    {
        if (!Search.IsEmpty() && !Row->SearchText.Contains(Search)) { continue; }
        if ((Filter == TEXT("Enabled") && !Row->bEnabled) || (Filter == TEXT("Disabled") && Row->bEnabled) ||
            (Filter == TEXT("Can tick") && !Row->bCanTick) || (Filter == TEXT("Cannot tick") && Row->bCanTick) ||
            (Filter == TEXT("Unregistered") && Row->bRegistered) || (Filter == TEXT("Actors") && Row->bComponent) ||
            (Filter == TEXT("Components") && !Row->bComponent)) { continue; }
        Results.Add(Row);
    }
    Results.Sort([this](const FRowPtr& A, const FRowPtr& B)
    {
        int32 Compare = 0;
        if (SortColumn == "Interval")
        {
            const bool bAFinite = FMath::IsFinite(A->Interval), bBFinite = FMath::IsFinite(B->Interval);
            if (bAFinite != bBFinite) { Compare = bAFinite ? -1 : 1; }
            else if (bAFinite) { Compare = A->Interval < B->Interval ? -1 : A->Interval > B->Interval ? 1 : 0; }
            else { Compare = Cell(*A, SortColumn).Compare(Cell(*B, SortColumn)); }
        }
        else if (SortColumn == "Group") { Compare = int32(A->Group) - int32(B->Group); }
        else if (SortColumn == "EndGroup") { Compare = int32(A->EndGroup) - int32(B->EndGroup); }
        else if (SortColumn == "Prerequisites") { Compare = A->Prerequisites - B->Prerequisites; }
        else { Compare = Cell(*A, SortColumn).Compare(Cell(*B, SortColumn), ESearchCase::IgnoreCase); }
        if (!Compare) { Compare = A->Key.Compare(B->Key); }
        return SortMode == EColumnSortMode::Descending ? Compare > 0 : Compare < 0;
    });
    bSyncing = true;
    List->ClearSelection();
    List->RequestListRefresh();
    for (const auto& Row : Results) { if (Selected.Contains(Row->Object)) { List->SetItemSelection(Row, true, ESelectInfo::Direct); } }
    bSyncing = false;
}

TSharedRef<ITableRow> STickInspector::MakeRow(FRowPtr Row, const TSharedRef<STableViewBase>& Owner)
{ return SNew(STickInspectorRow, Owner).Row(Row); }

void STickInspector::SelectionChanged(FRowPtr, ESelectInfo::Type Type)
{
    if (!bSyncing && Type != ESelectInfo::Direct && !Navigate(List->GetSelectedItems(), bFocusOnClick))
    { Message = TEXT("No selectable editor counterpart. Runtime-only actors remain inspectable in this list."); }
}

FText STickInspector::StatusText() const
{
    return FText::FromString(FString::Printf(TEXT("%d / %d rows | %d selected | %s | %s"), Results.Num(), Discovery->GetRows().Num(),
        List ? List->GetNumItemsSelected() : 0, Discovery->IsScanning() ? *FString::Printf(TEXT("Scanning (%d objects processed)"), Discovery->GetVisited())
        : TEXT("Snapshot; automatic refresh every 2 seconds while visible"), *Message));
}

FText STickInspector::DetailsText() const
{
    const TArray<FRowPtr> Selected = List ? List->GetSelectedItems() : TArray<FRowPtr>();
    if (Selected.Num() != 1) { return FText::FromString(TEXT("Ctrl/Shift selects multiple rows. Double-click focuses the owner. Configuration does not measure tick cost; use Unreal Insights to profile.")); }
    const FRow& Row = *Selected[0];
    return FText::FromString(FString::Printf(TEXT("%s | Any-thread: %s | Tick when paused: %s | Dedicated server allowed: %s | UTC: %s"),
        *Row.Key, Row.bAnyThread ? TEXT("Yes") : TEXT("No"), Row.bPaused ? TEXT("Yes") : TEXT("No"),
        Row.bDedicatedServer ? TEXT("Yes") : TEXT("No"), *Row.Captured.ToIso8601()));
}
