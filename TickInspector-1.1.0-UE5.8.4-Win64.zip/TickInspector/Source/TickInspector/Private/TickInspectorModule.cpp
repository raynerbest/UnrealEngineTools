#include "TickInspectorModule.h"
#include "Widgets/STickInspector.h"
#include "Framework/Docking/TabManager.h"
#include "ToolMenus.h"
#include "Styling/AppStyle.h"
#include "Widgets/Docking/SDockTab.h"

#define LOCTEXT_NAMESPACE "TickInspector"
static const FName TickInspectorTabName(TEXT("TickInspector"));

void FTickInspectorModule::StartupModule()
{
    if (IsRunningCommandlet()) { return; }
    bRegistered = true;
    FGlobalTabmanager::Get()->RegisterNomadTabSpawner(TickInspectorTabName,
        FOnSpawnTab::CreateRaw(this, &FTickInspectorModule::SpawnTab))
        .SetDisplayName(LOCTEXT("Tab", "Tick Inspector"))
        .SetTooltipText(LOCTEXT("Tooltip", "Inspect actor and component primary ticks"))
        .SetMenuType(ETabSpawnerMenuType::Hidden);
    UToolMenus::RegisterStartupCallback(FSimpleMulticastDelegate::FDelegate::CreateRaw(
        this, &FTickInspectorModule::RegisterMenus));
}

void FTickInspectorModule::ShutdownModule()
{
    if (!bRegistered) { return; }
    if (TSharedPtr<SDockTab> Tab = FGlobalTabmanager::Get()->FindExistingLiveTab(TickInspectorTabName))
    {
        Tab->RequestCloseTab();
    }
    UToolMenus::UnRegisterStartupCallback(this);
    UToolMenus::UnregisterOwner(this);
    FGlobalTabmanager::Get()->UnregisterNomadTabSpawner(TickInspectorTabName);
}

void FTickInspectorModule::RegisterMenus()
{
    FToolMenuOwnerScoped Owner(this);
    const FUIAction Action(FExecuteAction::CreateRaw(this, &FTickInspectorModule::OpenInspector));
    const FSlateIcon Icon(FAppStyle::GetAppStyleSetName(), "Icons.Search");
    UToolMenu* Tools = UToolMenus::Get()->ExtendMenu("LevelEditor.MainMenu.Tools");
    Tools->FindOrAddSection("TickInspector").AddMenuEntry("TickInspector.Open",
        LOCTEXT("Open", "Tick Inspector"), LOCTEXT("OpenHelp", "Open the Tick Inspector"), Icon, Action);
    UToolMenu* Toolbar = UToolMenus::Get()->ExtendMenu("LevelEditor.LevelEditorToolBar.User");
    Toolbar->FindOrAddSection("TickInspector").AddEntry(FToolMenuEntry::InitToolBarButton(
        "TickInspector.Open", Action, LOCTEXT("Toolbar", "Tick Inspector"),
        LOCTEXT("ToolbarHelp", "Inspect actor and component primary ticks"), Icon));
}

void FTickInspectorModule::OpenInspector()
{
    FGlobalTabmanager::Get()->TryInvokeTab(TickInspectorTabName);
}

TSharedRef<SDockTab> FTickInspectorModule::SpawnTab(const FSpawnTabArgs& Args)
{
    TSharedRef<STickInspector> Widget = SNew(STickInspector);
    Inspector = Widget;
    return SNew(SDockTab).TabRole(ETabRole::NomadTab)[Widget];
}

IMPLEMENT_MODULE(FTickInspectorModule, TickInspector)
#undef LOCTEXT_NAMESPACE
