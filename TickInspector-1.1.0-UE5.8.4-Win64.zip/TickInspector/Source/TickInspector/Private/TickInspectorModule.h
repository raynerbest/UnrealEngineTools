#pragma once

#include "Modules/ModuleManager.h"

class STickInspector;
class SDockTab;
class FSpawnTabArgs;

class FTickInspectorModule : public IModuleInterface
{
public:
    virtual void StartupModule() override;
    virtual void ShutdownModule() override;
    virtual bool SupportsDynamicReloading() override { return false; }
private:
    void RegisterMenus();
    void OpenInspector();
    TSharedRef<SDockTab> SpawnTab(const FSpawnTabArgs& Args);
    TWeakPtr<STickInspector> Inspector;
    bool bRegistered = false;
};
