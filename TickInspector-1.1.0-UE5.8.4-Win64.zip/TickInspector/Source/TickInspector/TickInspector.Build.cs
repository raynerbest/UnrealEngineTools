using UnrealBuildTool;

public class TickInspector : ModuleRules
{
    public TickInspector(ReadOnlyTargetRules Target) : base(Target)
    {
        PCHUsage = PCHUsageMode.UseExplicitOrSharedPCHs;
        PrivateDependencyModuleNames.AddRange(new[] {
            "Core", "CoreUObject", "Engine", "Slate", "SlateCore", "InputCore",
            "UnrealEd", "LevelEditor", "ToolMenus", "DesktopPlatform", "ApplicationCore", "TraceServices", "TraceLog"
        });
    }
}
