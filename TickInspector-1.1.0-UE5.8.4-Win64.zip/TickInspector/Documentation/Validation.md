# Validation

Use an isolated host project when running these automation tests. Tests create temporary worlds, perform editor Undo/Redo, and save a fixture map under that host's `Saved/TickInspectorTests`. They do not require host content or another plugin.

Automated test groups:

- `TickInspector.Foundation`: toolbar/menu registration, tab spawning and reuse.
- `TickInspector.Discovery`: loaded actor/component discovery, runtime/startup distinction, intervals, cancellation, destruction and world cleanup.
- `TickInspector.Operations`: persistent edits, Undo/Redo, instance-component configuration, invalid input and protected component rejection, PIE-session semantics, CSV encoding.
- `TickInspector.Persistence`: reload the saved fixture and inspect actor/component configuration. Run this again in a fresh process to verify disk persistence rather than cached objects.
- `TickInspector.Visualization`: rendering setup does not change material, custom depth, transform or package dirty state; diagnostics remain conservative.
- `TickInspector.WorldPartition`: loaded actors in a partitioned world remain discoverable without requesting cell loads.

The final validation report records the actual tests and build results. `-nullrhi` automation can verify Slate creation and behavior, but cannot establish visual quality of rendered viewport lines. Validate the cyan bounds, split/orthographic viewports, display scaling, multi-client PIE and large project-specific construction scripts interactively before relying on those workflows in production.

The discovery scan's wall-clock budget is a responsiveness mechanism, not a profiling measurement. The separate `TickInspector.Performance` automation tests exercise actual PIE CPU trace capture, automatic deadlines and editor Stop, post-PIE analysis, fixture attribution and restoration of tick batching. Profiling results cover primary tick CPU scopes only; they do not predict FPS savings. Rendered result charts still require interactive visual verification.
