# PIE performance capture validation — 1.1.0

Validated on Windows x64 with the installed Unreal Engine 5.8.4 editor and MSVC 14.44.35217, 2026-11-01.

## Build and functional results

Changed translation units compiled successfully using UnrealBuildTool-generated compiler response files; the plugin linked successfully against the installed engine. The main editor held the previous plugin DLL open, so linking and automation used an isolated plugin host. The installed project uses a versioned DLL filename in `UnrealEditor.modules` and requires an editor restart. Its SHA-256 matches the independently tested DLL:

`4EFE03D5B60D3514F93EC7370ABAD80AF5356846176431EE48374EC8B303F05A`

The final `TickInspector` automation run completed with **12 passing tests, 0 failed** (11 clean passes and one pass with an optional HLOD-module import warning in the isolated World Partition fixture). Report: `Saved/TickInspectorBuild/PerformanceHeadless/Report/index.json`, created `2026.11.01-07.40.58` UTC.

The two new performance tests use actual PIE and CPU traces, not fabricated timings:

- Automatic deadline: 58 measured world frames; two numbered actor instances each recorded 116 calls (actor tick plus its owned component tick).
- Editor Stop before the deadline: 63 measured world frames; each actor recorded 126 calls.
- Both actors own components named `PerformanceComponent`; ownership remains separate.
- Invalid duration and concurrent requests are rejected.
- PIE ends, analysis completes, temporary object stat identities are restored before world cleanup, and the original tick-batching value is restored.
- The existing discovery, editor integration, operations, CSV, persistence, PIE isolation, viewport and loaded World Partition tests still pass.

These fixture measurements establish capture and attribution behavior, not performance of the user's gameplay map.

## Visual verification limitation

The rendering-enabled run did not reach the screenshot tests because the isolated editor was still compiling default-material shaders. Its temporary process was stopped. No rendered screenshot or visual approval is claimed. The headless suite constructs the inspector, but does not establish rendered chart layout, DPI behavior or viewport appearance. The performance tests can save `PerformanceAutomatic.png` and `PerformanceManual.png` when run with rendering available.

The capture is an instrumented PIE workload: it enables CPU/object timing and temporarily disables tick batching. Results represent synchronous inclusive actor/component CPU scopes, not predicted FPS savings, total actor cost, GPU work, or arbitrary detached asynchronous work. See the README and architecture notes for coverage and instrumentation details.
