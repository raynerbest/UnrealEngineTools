# Validation results — UE 5.8.4 / Windows x64

Engine: 5.8.4, changelist 58902052. Compiler: Visual Studio 2022 / MSVC 14.44.35217; Windows SDK 10.0.22621.0.

The Editor module was compiled incrementally after each implementation phase using UnrealBuildTool with unity, shared PCH and PCH disabled, with sequential compiler execution. This verified direct includes against the installed engine's public APIs. The last build completed without compiler warnings.

| Check | Result |
| --- | --- |
| Foundation: Tools entry, toolbar button, dockable tab reuse | Passed |
| Discovery, component discovery, cancellation and world cleanup | Passed |
| Runtime versus startup-enabled configuration | Passed |
| Persistent actor/component edits, Undo/Redo, save | Passed |
| Invalid values, internal groups and construction-script component protections | Passed |
| CSV quoting, Unicode and spreadsheet formula handling | Passed |
| Actual PIE session, registered Tick changes, editor counterpart and end-PIE cleanup | Passed |
| Fresh-process reload of saved actor and instance-component configuration | Passed |
| Highlight setup does not alter materials, custom depth, transforms or package dirty state | Passed |
| Loaded-actor discovery in a World Partition world | Passed |
| New independent installation: full 10-test suite | Passed; zero failures |
| New independent installation: second-process persistence reload | Passed; zero failures |
| UAT `BuildPlugin` packaging | Passed using the separately compiled DLL with `-NoHostPlatform` |

The minimal hosts explicitly enabled only TickInspector and disabled engine plugins by default. The World Partition fixture emitted an engine HLOD-template import warning for the disabled `WorldPartitionHLODUtilities` plugin. No test failed, and production TickInspector has no dependency on that plugin.

Rendered screenshot attempts initialized D3D11/D3D12 but remained in first-time engine material/shader-cache compilation. The optional preview processes were stopped. **No rendered screenshot or interactive viewport visual review is claimed.** The screenshot automation test is provided for a rendering-enabled host with its shader cache ready; NullRHI skips that capture. The non-destructive visualization setup is covered by functional automation.

The distributed `VALIDATION.json` records independent-install results and SHA-256 file hashes. The binary targets this engine build; source is provided for recompilation. Fab publisher metadata, listing assets and marketplace review remain separate from technical packaging.
