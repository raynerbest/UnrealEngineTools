# Architecture and UE 5.8.4 API notes

`TickInspector.uplugin` declares a single `Editor` module, loaded at `PostEngineInit`. `CanContainContent=false` means no assets must be mounted or cooked. Built-in C++ modules are link dependencies in `TickInspector.Build.cs`; they are not dependencies on the host project's plugins. All headers are engine public headers. The module does not alter the host `.uproject` or any other plugin.

## Editor integration

`FTickInspectorModule` registers a named nomad tab through `FGlobalTabmanager`. Both ToolMenus entry points invoke that name, reusing an existing tab. `UToolMenus::RegisterStartupCallback` avoids relying on menu construction order. `FToolMenuOwnerScoped` establishes ownership so shutdown can remove only this plugin's entries. Shutdown unregisters menus and the tab spawner, and requests closure of its tab. Dynamic module reloading is disabled; restart the editor after updating the binary. Commandlets skip UI registration.

## Data flow and object lifetime

`STickInspector` owns `FDiscoveryService` and the optional viewport drawing service. The widget's Slate tick drives incremental scanning while visible. Each scan walks the selected world's loaded levels and their actor arrays by index rather than retaining a UObject iterator across garbage collections. Component work queues contain `TWeakObjectPtr` references. Rows contain copied scalars/strings plus weak object/owner references; they never own, copy or cache an `FTickFunction*`.

The scanner uses a separate pending buffer and publishes completed scans. Deduplication prevents duplicate actors/components in the snapshot. Auto-refresh, level-added/removed delegates, object property/replacement delegates, world cleanup and Undo callbacks request new scans. Rows are revalidated at action time. Selection restoration uses weak object identity rather than object names, so a new actor reusing an old path is not silently selected. Delegates are explicitly removed when their service is destroyed.

World selection enumerates `GEngine->GetWorldContexts()` and admits only `Editor` and `PIE` contexts. It does not assume `GWorld` is the inspected world. Labels identify PIE instance/network mode. `EditorUtilities::GetEditorWorldCounterpartActor` supplies navigation counterparts without path guessing.

## Tick semantics

`AActor::SetActorTickEnabled` and `UActorComponent::SetComponentTickEnabled` invoke live scheduler enable state and guard tick capability. `bStartWithTickEnabled` is reflected startup configuration. They are different values.

`FTickFunction::IsTickFunctionEnabled` includes cooldown state. `IsTickFunctionRegistered` is separate from `UActorComponent::IsRegistered`. None proves that a tick executed in a sampled frame. `GetActualTickGroup` has a documented frame-validity window; the inspector reports configured start/end groups rather than inventing a stable actual group from arbitrary editor reads.

Both primary tick structs are `EditDefaultsOnly` in the engine headers. The inspector deliberately writes supported level-instance serialized overrides rather than changing class defaults. Native/instance component persistence must be validated against construction behavior. SCS/UCS components are rejected for persistent edits. Runtime capability and prerequisites are read-only.

## Transactions

`FScopedTransaction` captures one persistent batch. `Modify()` records each target and component owner before reflected fields change. `PreEditChange`/`PostEditChangeProperty` notify the engine; objects are weakly revalidated around notifications because components can reconstruct. Packages, including external actor packages, remain dirty for the normal save workflow. Invalid or no-op batches do not create a useful transaction. `FEditorUndoClient` requests fresh snapshots after Undo/Redo.

PIE operations use actor/component enable/group setters and `FTickFunction::UpdateTickIntervalAndCoolDown`. They do not create persistent editor transactions or modify editor counterparts. All UObject reads and mutations execute on the game thread.

## Visualization and dependencies

`UDebugDrawService` is called by the editor viewport renderer. A plugin-owned delegate projects cached owner bounds through that viewport's `FSceneView`. It filters by world, validates weak world references, and unregisters on destruction. No renderer hooks, component injection, custom-depth changes or material replacement are needed. It requires `OnScreenDebug` and is not depth-occluded.

World Partition uses the same loaded UObject path as other worlds. Streaming is observed, not controlled; the plugin does not hold `FWorldPartitionReference` objects or call actor-loading APIs.

## Timed PIE CPU capture

`FPerformanceCapture` owns a local PIE request, a file CPU trace, and an asynchronous TraceServices analysis session. Temporary `ULevelEditorPlaySettings` are strongly referenced and force one in-process standalone-mode client without saving user settings. `PostPIEStarted` starts recording and the real-time deadline; `PrePIEEnded` closes the trace and restores instrumentation before world teardown. The core ticker enforces the deadline independently of Slate visibility and publishes copied results after analysis completes. Service destruction removes its delegates/ticker, cancels only its own request/session, restores stats, and stops its analysis.

UE 5.8's `FUObjectItem::CreateStatID` builds names from FName display entries without instance numbers. Default UObject stats can therefore merge `Actor_0` and `Actor_1`, including their same-named components. Capture temporarily replaces each inspected PIE object's `FUObjectItem::StatID` with a unique dynamic UObject stat identifier. Weak keys retain the saved identifiers for restoration; graph data retains copied labels/paths and capture-local identities. No actor properties, assets, tick callbacks or engine source files are replaced. Ownership is discovered at world pre-actor tick; objects living entirely between scans can remain unattributed.

UObject and TaskGraphTasks groups, primary stats collection and named events are enabled for the capture, then restored. A tagged `ECVF_SetByTemp` override disables tick batching; removing the tag restores the existing configuration/priority. If a higher-priority setting prevents this, capture fails explicitly rather than silently losing actor scopes. Captures do not interrupt an already-active trace or PIE session.

Analysis walks CPU scope nesting and charges only mapped outer UObject scopes immediately under engine tick tasks or the component tick execution scope. Nested Blueprint/object scopes are not added twice. Standard primary actor/component ticks are covered; custom instrumented tick implementations using the same scope layout can also contribute. Arbitrary secondary ticks and detached async work are not guaranteed coverage. Results sum synchronous inclusive CPU work per actor and normalize by recorded PIE world-frame markers. Thread overlap means this sum is not frame wall time or predicted FPS savings. Trace files remain available for Unreal Insights.
