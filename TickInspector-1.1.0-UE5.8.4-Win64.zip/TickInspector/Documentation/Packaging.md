# Independent distribution

The plugin has one Editor module and no runtime/content dependency. Source is included so another UE 5.8.4 installation can rebuild it. The Windows binary is specific to its engine build ID. The `.uplugin` intentionally advertises only Win64 until other platforms are compiled and validated.

Standard Unreal packaging:

```powershell
& '<UE>/Engine/Build/BatchFiles/RunUAT.bat' BuildPlugin `
  '-Plugin=<Project>/Plugins/TickInspector/TickInspector.uplugin' `
  '-Package=<Output>/TickInspector' -TargetPlatforms=Win64
```

`Scripts/build_validate.py` also supports an isolated strict editor build and automation tests. It does not edit user-wide compiler configuration or host project content. On memory-constrained machines it builds sequentially without PCH, unity or UBA-distributed compiler execution. This is slower but limits peak compiler memory.

Install the delivered plugin folder in a clean project's `Plugins` directory and restart Unreal Editor. For source distribution, omit generated `Binaries`/`Intermediate` and include `Source`, `Config`, documentation and the descriptor. Never ship the validation host, local caches, saved fixture maps or unrelated project plugins.

Before publishing on Fab, supply the publisher's identity, support details, listing media and chosen licensing terms, and complete Fab's submission/review process. Technical packaging is not a claim of marketplace approval. No external proprietary assets or third-party code are bundled with this plugin.
