# debug_export_csv.py
import os
import csv
import io

def _sanitize_value(v: str) -> str:
    if v is None:
        return ""
    # Limpia saltos de línea para una celda legible (csv igual permite \n, pero suele ser molesto)
    v = str(v).replace("\r\n", " ").replace("\r", " ").replace("\n", " ")
    return v

def save_csv_from_arrays(keys, values, abs_path, append=False, include_header=True, delimiter=",", quotechar='"', overwrite=True):
    """
    Escribe un archivo CSV con 2 columnas: Field, Value.
    - keys/values: listas de igual longitud
    - abs_path: ruta absoluta al .csv
    - append: si True, agrega al final
    - include_header: si True, escribe encabezado 'Field','Value' (solo cuando no existe o cuando no haces append)
    - delimiter / quotechar: personalizables
    """
    if len(keys) != len(values):
        raise ValueError(f"Length mismatch: keys={len(keys)} values={len(values)}")
    if not abs_path:
        raise ValueError("abs_path required")
    # Validate dialect before opening a destination in truncate mode.
    csv.writer(io.StringIO(), delimiter=delimiter, quotechar=quotechar)

    folder = os.path.dirname(os.path.abspath(abs_path))
    os.makedirs(folder, exist_ok=True)

    mode = "a" if append else ("w" if overwrite else "x")

    with open(abs_path, mode, encoding="utf-8", newline="") as f:
        writer = csv.writer(f, delimiter=delimiter, quotechar=quotechar, quoting=csv.QUOTE_MINIMAL)
        # Header si corresponde (si no haces append o si el archivo no existía)
        if include_header and (not append or f.tell() == 0):
            writer.writerow(["Field", "Value"])
        # Filas
        for k, v in zip(keys, values):
            writer.writerow([_sanitize_value(k), _sanitize_value(v)])
    return abs_path
