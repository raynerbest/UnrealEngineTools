"""Editor actions. Blueprint passes the widget as a typed Python input.

Debug values are data, never interpolated into Python source. Runtime sampling
and SaveGame remain in Blueprint and do not depend on this editor module.
"""
import math
import os
import re
import uuid
from datetime import datetime, timezone

import debug_export_csv
import debug_export_txt


def _unreal():
    import unreal
    return unreal


def _get(obj, name, fallback=None):
    try:
        return obj.get_editor_property(name)
    except Exception:
        if fallback:
            return obj.get_editor_property(fallback)
        raise


def _values(entry):
    return _get(entry, "DebugValues", "DebugValues_7_177BB4A0485862662267DD8F7AB3C46C")


def _status(widget, message, error=False):
    u = _unreal()
    _get(widget, "txt_DebugManagerState").set_text(u.Text(message))
    (u.log_warning if error else u.log)("Character Debug: " + message)


def _export_enabled(widget, enabled):
    for name in ("btn_ExportTXT", "btn_ExportCSV"):
        _get(widget, name).set_is_enabled(enabled)


def reset_selection(widget):
    """Invalidate old captures before attempting to load another profile."""
    _export_enabled(widget, False)
    _get(widget, "vb_DebugSaveEntryInfo").clear_children()
    entry = _get(widget, "SelectedEntryInfo")
    values = _values(entry)
    values.clear()
    # Struct properties are returned by value; explicitly assign the modified copy.
    try:
        entry.set_editor_property("DebugValues", values)
    except Exception:
        entry.set_editor_property("DebugValues_7_177BB4A0485862662267DD8F7AB3C46C", values)
    widget.set_editor_property("SelectedEntryInfo", entry)
    _status(widget, "Selecciona una captura. Si la lista está vacía, guarda una durante Play.")


def selection_changed(widget):
    enabled = bool(_values(_get(widget, "SelectedEntryInfo")))
    _export_enabled(widget, enabled)
    _status(widget, "Captura seleccionada. Puedes exportarla a TXT o CSV." if enabled
            else "La captura no contiene métricas.")


def export_widget(widget, extension):
    try:
        values = _values(_get(widget, "SelectedEntryInfo"))
        if not values:
            raise ValueError("Selecciona una captura con métricas antes de exportar.")
        if extension not in ("txt", "csv"):
            raise ValueError("Formato de exportación no compatible.")
        # A single item traversal keeps keys and values paired.
        pairs = sorted((str(k), str(v)) for k, v in values.items())
        keys, data = zip(*pairs)
        folder = os.path.join(_unreal().Paths.project_saved_dir(), "CharacterDebug", "Exports")
        name = "debug_" + datetime.now(timezone.utc).strftime("%Y-%m-%d_%H-%M-%S_%f")
        path = os.path.abspath(os.path.join(folder, name + "_" + uuid.uuid4().hex[:8] + "." + extension))
        if extension == "csv":
            debug_export_csv.save_csv_from_arrays(keys, data, path, delimiter=";", overwrite=False)
        else:
            debug_export_txt.save_from_arrays(keys, data, path, ensure_newline_at_end=True, overwrite=False)
        widget.set_editor_property("OutPath", path)
        _status(widget, "Exportado: " + path)
        return path
    except Exception as exc:
        _status(widget, "No se pudo exportar: " + str(exc), True)
        return None


def place_manager(widget):
    """Reuse the existing manager; never delete actors to change a profile."""
    u = _unreal()
    try:
        wrapper = _get(widget, "DebugPickerWrapper", "Debug Picker Wrapper")
        profile = _get(wrapper, "DebugDataAsset") if wrapper else None
        if not profile:
            raise ValueError("Selecciona un perfil de debug antes de colocar el manager.")
        subsystem = u.get_editor_subsystem(u.EditorActorSubsystem)
        widget_path = widget.get_class().get_path_name()
        root = "/Game/CharacterDebugTool" if widget_path.startswith("/Game/") else "/CharacterDebugTool"
        manager_class = u.load_class(None, root + "/Blueprints/BP_CharacterDebugManager.BP_CharacterDebugManager_C")
        managers = [actor for actor in subsystem.get_all_level_actors()
                    if u.MathLibrary.class_is_child_of(actor.get_class(), manager_class)]
        if len(managers) > 1:
            raise ValueError("Hay varios managers en el nivel. Conserva uno antes de continuar.")
        with u.ScopedEditorTransaction("Configurar Character Debug Manager"):
            actor = managers[0] if managers else subsystem.spawn_actor_from_class(manager_class, u.Vector())
            if not actor:
                raise RuntimeError("No se pudo crear el manager en el nivel actual.")
            actor.modify()
            actor.set_editor_property("DebugData", profile)
            actor.set_actor_label("Character Debug Manager")
        subsystem.set_selected_level_actors([actor])
        widget.set_editor_property("DebugManagerPlaced", True)
        _status(widget, "Manager actualizado. Guarda el nivel para conservar los cambios.")
        return actor
    except Exception as exc:
        _status(widget, "No se pudo configurar el manager: " + str(exc), True)
        return None


def parse_location(text):
    """Accept Unreal X/Y/Z text (including grouped numbers), or three numbers."""
    text = str(text).strip()
    named = re.fullmatch(r"\s*X\s*=\s*(.*?)\s+Y\s*=\s*(.*?)\s+Z\s*=\s*(.*?)\s*", text, re.I)
    if named:
        parts = [part.replace(",", "") for part in named.groups()]
    else:
        parts = text.replace(",", " ").split()
    if len(parts) != 3:
        raise ValueError("Introduce X=100 Y=200 Z=300, o tres números separados por espacios.")
    numbers = tuple(float(part) for part in parts)
    if not all(math.isfinite(number) for number in numbers):
        raise ValueError("Las coordenadas deben ser números finitos.")
    return numbers


def go_to_location(widget):
    try:
        u = _unreal()
        location = u.Vector(*parse_location(_get(widget, "EditableTextBox_176").get_text()))
        subsystem = u.get_editor_subsystem(u.UnrealEditorSubsystem)
        _, rotation = subsystem.get_level_viewport_camera_info()
        subsystem.set_level_viewport_camera_info(location, rotation)
        _status(widget, "Cámara situada en la ubicación indicada.")
        return True
    except Exception as exc:
        _status(widget, "No se movió la cámara: " + str(exc), True)
        return False
