"""Character Debug entry points in Unreal Editor (no runtime dependency)."""
import unreal

OWNER = "CharacterDebugTool"
SECTION = "CharacterDebugTool"
ENTRY = "CharacterDebugTool.OpenInspector"
TOOLBAR = "LevelEditor.LevelEditorToolBar.User"
TOOLS_MENU = "LevelEditor.MainMenu.Tools"


def widget_asset_path():
    registry = unreal.AssetRegistryHelpers.get_asset_registry()
    for path in (
        "/CharacterDebugTool/Editor/Utilities/CharacterDebugEditor",
        "/Game/CharacterDebugTool/Utilities/CharacterDebugEditor",
    ):
        if registry.get_assets_by_package_name(path):
            return path
    raise RuntimeError("No se encuentra el inspector de Character Debug Tool.")


def open_inspector():
    """Spawn or focus the registered tab; repeated clicks reuse the same tab."""
    asset = unreal.load_asset(widget_asset_path())
    subsystem = unreal.get_editor_subsystem(unreal.EditorUtilitySubsystem)
    widget = subsystem.spawn_and_register_tab(asset)
    if not widget:
        raise RuntimeError("No se pudo abrir el inspector de Character Debug Tool.")
    return widget


def unregister():
    menus = unreal.ToolMenus.get()
    for name in (TOOLBAR, TOOLS_MENU):
        menus.remove_entry(name, SECTION, ENTRY)
    menus.refresh_all_widgets()


def register():
    """Extend early or late safely. Stable entry names prevent duplicates."""
    menus = unreal.ToolMenus.get()
    for name, kind in ((TOOLBAR, unreal.MultiBlockType.TOOL_BAR_BUTTON),
                       (TOOLS_MENU, unreal.MultiBlockType.MENU_ENTRY)):
        menu = menus.extend_menu(name)
        menus.remove_entry(name, SECTION, ENTRY)
        menu.add_section(SECTION, "Character Debug")
        entry = unreal.ToolMenuEntry(name=ENTRY, type=kind)
        entry.set_label("Character Debug")
        entry.set_tool_tip("Abrir el inspector de capturas y configurar el overlay de personajes.")
        entry.set_icon("EditorStyle", "Icons.Adjust")
        entry.set_string_command(unreal.ToolMenuStringCommandType.PYTHON, "",
                                 "import character_debug_menu; character_debug_menu.open_inspector()")
        menu.add_menu_entry(SECTION, entry)
    menus.refresh_all_widgets()
    return True
