# debug_export_arrays.py
import os

def _sanitize_value(v: str) -> str:
    if v is None:
        return ""
    # Todo a string y sin saltos de línea para mantener 1 línea por par
    v = str(v).replace("\r\n", " ").replace("\r", " ").replace("\n", " ")
    return v

def serialize_pairs_from_arrays(keys, values, sep=": "):
    """
    Devuelve el texto en formato:
    key1: value1
    key2: value2
    ...
    """
    if len(keys) != len(values):
        raise ValueError(f"Length mismatch: keys={len(keys)} values={len(values)}")

    lines = []
    for k, v in zip(keys, values):
        k = _sanitize_value(k)
        v = _sanitize_value(v)
        lines.append(f"{k}{sep}{v}")
    return "\n".join(lines)

def save_from_arrays(keys, values, abs_path, append=False, sep=": ", ensure_newline_at_end=False, overwrite=True):
    """
    keys:   lista de strings (llaves)
    values: lista de strings (valores)
    abs_path: ruta absoluta al .txt
    append: si True, agrega al final; si False, sobrescribe
    sep: separador entre key y value (por defecto ': ')
    ensure_newline_at_end: agrega '\n' al final del archivo si quieres separar bloques
    """
    if not abs_path:
        raise ValueError("abs_path required")

    text = serialize_pairs_from_arrays(keys, values, sep=sep)

    folder = os.path.dirname(os.path.abspath(abs_path))
    os.makedirs(folder, exist_ok=True)

    needs_separator = False
    if append and os.path.isfile(abs_path) and os.path.getsize(abs_path):
        with open(abs_path, "rb") as existing:
            existing.seek(-1, os.SEEK_END)
            needs_separator = existing.read(1) not in (b"\n", b"\r")
    mode = "a" if append else ("w" if overwrite else "x")
    with open(abs_path, mode, encoding="utf-8") as f:
        if needs_separator and text:
            f.write("\n")
        f.write(text)
        if ensure_newline_at_end:
            f.write("\n")
    return abs_path
