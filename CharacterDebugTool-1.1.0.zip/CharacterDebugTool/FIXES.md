# Correcciones implementadas

## Actualización 1.1: acceso desde el editor y aspecto del overlay

- Se corrigieron los textos de atajos: la versión anterior consultaba `Mappings`, obsoleto en UE 5.8. Ahora se usa `DefaultKeyMappings`, con textos de respaldo, color visible y actualización también en el diseñador.
- Botón **Character Debug** con icono plano del editor en la barra superior y entrada en **Tools**. El arranque Python del plugin registra ambos accesos y se puede repetir sin acumular entradas.
- **F6** alterna seis colores; **− / +** y **Num − / Num +** ajustan la escala entre el 60 y el 160 %; **F7** restablece blanco y 100 %. Solo se procesan con el overlay abierto y el foco de Play.
- El aspecto se conserva al ocultar/mostrar y se almacena junto al historial al guardar una captura. La paleta es editable en el manager.
- El plugin de contenido incluye su integración de editor y declara las dependencias; no requiere compilar código C++ para instalarlo en otro proyecto UE 5.8.
- Validación 1.1 aprobada: siete comprobaciones de UX tanto en el proyecto de desarrollo como en el plugin independiente, siete pruebas unitarias y cook de 30 paquetes para Windows sin errores. Se verificó expresamente que reasignar las acciones a F10/F11 cambia los textos mostrados. Informes: `Saved/Tests/overlay_ux_validation.json` y `Saved/PluginBuild/20261031-201823/ValidationFinal.log`.
- Entrega 1.1: `Dist/CharacterDebugTool-1.1.0.zip`. Es necesario reiniciar Unreal tras instalar o actualizar para cargar automáticamente el botón de la barra.

## Integridad y ejecución

- Reconstruida la propiedad `BP_DA_DebugFeatures.DebugFeatures` con el tipo de estructura correcto y restaurado el perfil de ejemplo. La carga desde un proceso nuevo ya no registra `Unknown structure`.
- El overlay resuelve el personaje poseído por su jugador propietario en cada ciclo. Arranca aunque todavía no haya personaje y muestra `N/A` cuando no existe uno válido.
- Un solo temporizador del overlay controla el muestreo y se limpia en `Destruct`. Las métricas respetan sus intervalos mediante `NextRefreshTime`; el mínimo efectivo es 0,1 s. Un cambio de personaje fuerza una lectura.
- Las capturas leen los valores de nuevo mediante `ReadSnapshot` y usan Gameplay Tags como claves mediante `GetFeatureId`. El nombre visible deja de determinar la identidad del campo.
- Class Name y Controller Class obtienen nombres de clase.
- La carga de un SaveGame incompatible crea un historial válido. Se comprueba el resultado de escritura y se informa al guardar o fallar. Intentar guardar con el overlay cerrado muestra instrucciones.
- Se conservan las últimas 500 capturas. Los slots vacíos se resuelven por perfil; el perfil de ejemplo mantiene `DebugSave`.

## Widget de editor

- Colocar el manager valida el perfil antes de editar el nivel, reutiliza el actor existente, no elimina actores y admite transacciones de editor. Si encuentra varios managers, informa del conflicto.
- Los botones ejecutan acciones Python con un parámetro de objeto tipado. La referencia se cachea en `ScriptWidget` antes de usarla: pasar `Self` directamente al thunk de Python de esta versión producía una conversión incorrecta, detectada mediante una prueba del evento real.
- Se retiraron los cinco grafos auxiliares antiguos que construían comandos Python o rutas a partir de los valores de debug.
- Cambiar de perfil limpia selección y detalles. Exportar requiere una captura con datos. El widget informa de resultados y errores.
- Las exportaciones usan fecha UTC de 24 horas, microsegundos y un sufijo aleatorio; la creación exclusiva protege archivos existentes.
- Las etiquetas de las capturas muestran fecha/hora local con segundos.
- La navegación valida coordenadas, rechaza NaN/infinito y conserva la rotación de cámara.
- Los exportadores normalizan CRLF, CR y LF; TXT separa bloques añadidos y CSV escribe cabecera al añadir a un archivo vacío. Se valida el dialecto CSV antes de abrir el destino para sobrescribir.

## Distribución

El constructor de `Scripts/build_standalone_plugin.py` usa un proyecto temporal para migrar assets con Unreal al punto de montaje `/CharacterDebugTool`. Se separan las utilidades y widgets de inspección bajo `Editor`, se declara su exclusión de cook y se declaran las dependencias. Las rutas del proyecto de desarrollo no se trasladan.

El constructor comprueba referencias a `/Game`, dependencias de ejecución hacia contenido de editor y carga desde un proceso nuevo. El plugin registra su tabla mediante `Config/GameplayTags.ini`; en UE 5.8, la modificación de una rama de configuración desde un plugin usa `<Rama>.ini`.

## Validación

- Siete pruebas unitarias de los exportadores y el parser: aprobadas.
- Compilación de los Blueprints de la herramienta: aprobada.
- Once comprobaciones de integración en un proceso nuevo: aprobadas, incluidas Construct, evento real del botón CSV, referencia tipada, datos con Unicode/comillas/barras, estados de selección, creación/reutilización del manager, slots, lectura real de Speed y cambio de personaje con throttling.
- Arranque y parada de PIE en el proyecto existente: sin nuevos errores de ejecución de Blueprint. No equivale a una prueba manual completa de todos los atajos y escenarios de juego.
- Distribución migrada: carga y compilación aprobadas en un proyecto independiente; sin dependencias hacia `/Game` ni del contenido de ejecución hacia la carpeta `Editor`. Registro de la tabla de tags e inicialización real del widget aprobados.
- La misma validación también aprobó con `DisableEnginePluginsByDefault=true`, usando únicamente el plugin y sus dependencias declaradas.
- Cook focalizado para Windows: 30 paquetes cocinados, cero errores. Se usó `-CookSkipRequests` y la ruta física del contenido para comprobar los assets y sus referencias sin incluir paquetes de arranque y mapas de ejemplo del motor. No es una prueba de un ejecutable completo de juego. Registro: `Saved/PluginBuild/20261031-103848/CookAssetsFinal.log`.
- Entrega instalable: `Dist/CharacterDebugTool` y `Dist/CharacterDebugTool-1.0.0.zip`.
- Registros e informes: `Saved/Logs/CodexValidation.log`, `Saved/Tests/character_debug_validation.json` y `Saved/PluginBuild`.
- Respaldo anterior a los cambios: `Saved/CodexBackups/20261031-095906`.

La exportación Python es de editor. El soporte de multijugador/red, múltiples jugadores locales y otras versiones del motor requiere validación adicional. El proyecto de desarrollo conserva su mapa y su contenido de ejemplo.
