# Character Debug Tool

Herramienta para Unreal Engine 5.8: overlay de métricas del personaje, capturas persistentes y un inspector de capturas en el editor.

## Uso en este proyecto

1. Reinicia el editor tras actualizar y pulsa **Character Debug** en la barra superior. También está en **Tools → Character Debug**. Se reutiliza la misma pestaña al pulsar varias veces.
2. Selecciona `DA_DefaultDebugFeatures` u otro perfil en el selector del widget.
3. Pulsa el botón para colocar el manager. Si ya hay uno, se actualiza sin eliminarlo. La operación admite Undo. Guarda el nivel.
4. Inicia Play. Suelta **0** para mostrar/ocultar el overlay y **9** para guardar una captura con el overlay abierto.
5. Detén Play, vuelve a seleccionar el perfil en el inspector y elige una captura. Los botones TXT/CSV se habilitan cuando hay datos.
6. La exportación aparece en `Saved/CharacterDebug/Exports`. La interfaz muestra la ruta o el motivo del fallo.

Con el overlay abierto y el foco en la ventana de Play:

| Tecla | Acción |
| --- | --- |
| 0 (al soltar) | Mostrar u ocultar el overlay |
| 9 (al soltar) | Guardar una captura |
| F6 | Alternar entre seis colores |
| − / + (o Num − / Num +) | Reducir o aumentar la escala en pasos del 10 % |
| F7 | Restablecer color blanco y escala del 100 % |

La escala está limitada al 60–160 % para mantener el contenido legible. El aspecto se conserva al cerrar y abrir el overlay durante Play y se guarda en el historial al capturar. Los perfiles recuperan el aspecto del último historial cargado. La paleta puede personalizarse en **Overlay Appearance → Overlay Colors** del manager.

Los textos de ayuda están asignados también en PreConstruct y leen `DefaultKeyMappings` de Enhanced Input en UE 5.8. Si no hay un mapping configurado, muestran los controles predeterminados.

La exportación TXT/CSV y la navegación de la cámara son funciones de editor. El overlay y SaveGame usan Blueprints de ejecución y no requieren Python en el juego.

## Perfiles y métricas

Cada perfil `BP_DA_DebugFeatures` contiene secciones, una lista de Gameplay Tags, la tabla de lógica y un slot. Para nuevas métricas:

1. Implementa una clase derivada de `BP_GetFeatureValue` y su función `GetFeatureValue_BPI`.
2. Registra el tag en `DT_DebugTags` y añade una fila en `DT_FeatureLogic` con tag, nombre, clase e intervalo.
3. Añade el tag a una sección del perfil.

El overlay consulta el personaje del jugador propietario cada 0,1 s. Cada métrica respeta su intervalo, con un mínimo efectivo de 0,1 s. Un intervalo cero usa ese mínimo; no significa Tick ni lectura única. Cambiar de personaje fuerza la próxima lectura; sin personaje se muestra `N/A`. Al cerrar el overlay se limpia su temporizador.

Una captura vuelve a leer las métricas dentro de la misma operación y usa Gameplay Tags como claves, de modo que cambiar un nombre visible no cambia su identidad. Los guardados anteriores con nombres visibles siguen siendo legibles. El historial conserva las **500 capturas más recientes** por slot.

Un slot vacío genera un nombre a partir de la ruta del perfil. Un nombre explícito permite compartir historial deliberadamente. El perfil de ejemplo conserva `DebugSave` para mantener acceso a capturas anteriores.

La navegación admite `X=100 Y=200 Z=300` o `100 200 300`; valida las coordenadas y conserva la rotación de la cámara. Los errores no mueven la cámara.

## Plugin instalable

El script `Scripts/build_standalone_plugin.py` crea un plugin de contenido en `Dist/CharacterDebugTool-<fecha>`. La migración se realiza con Unreal en un proyecto temporal dentro de `Saved/PluginBuild`; el mapa y los assets de desarrollo permanecen en sus rutas actuales. El constructor valida la carga independiente y ejecuta un cook focalizado de assets para Windows antes de entregar la carpeta.

Para instalar la carpeta generada:

1. Copia la carpeta a `<TuProyecto>/Plugins/CharacterDebugTool`, de modo que contenga `CharacterDebugTool.uplugin`.
2. Abre el proyecto y habilita Character Debug Tool si fuera necesario. Las dependencias Enhanced Input, Python Editor Script y Editor Scripting Utilities están declaradas por el plugin.
3. Activa **Show Plugin Content** en el Content Browser.
4. Pulsa **Character Debug** en la barra del editor o en **Tools → Character Debug**. Como alternativa, ejecuta `CharacterDebugTool/Editor/Utilities/CharacterDebugEditor` desde el Content Browser.

El plugin registra su tabla de tags mediante configuración. Su carpeta `Editor` está excluida del cook. El alcance actual del manager es el jugador local 0; multijugador de red y múltiples jugadores locales requieren validación específica antes de usarse como funcionalidades soportadas.

## Validación

- `Tests/test_debug_exports.py`: exportación, normalización de texto, protección de archivos existentes y coordenadas.
- `Scripts/validate_character_debug.py`: compilación, selección del widget, exportaciones con Unicode/comillas, creación y reutilización del manager y lectura real de una métrica en un proceso nuevo de Unreal.
- `Scripts/validate_packaged_plugin.py`: carga y compilación del plugin migrado y registro de tags en un proceso nuevo.
- `Scripts/validate_overlay_ux.py`: textos y visibilidad, mappings UE 5.8, color/escala/restablecer y registro único de los botones del editor.

Los respaldos previos a la corrección están en `Saved/CodexBackups`. Las pruebas generan informes en `Saved/Tests` y registros en `Saved/Logs`.
